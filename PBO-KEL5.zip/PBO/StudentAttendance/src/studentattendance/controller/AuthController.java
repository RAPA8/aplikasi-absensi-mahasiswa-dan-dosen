package studentattendance.controller;

import studentattendance.db.DatabaseConnection;
import studentattendance.model.*;
import studentattendance.util.PasswordUtil;

import java.sql.*;

/**
 * Handles user authentication for all roles.
 */
public class AuthController {

    private static User currentUser     = null;
    private static Student currentStudent   = null;
    private static Lecturer currentLecturer = null;

    /** Attempt login. Returns true if credentials are valid and active. */
    public static boolean login(String username, String password) {
        String sql = "SELECT id, username, password, role, is_active FROM users WHERE username = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, username.trim());
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                boolean active   = rs.getBoolean("is_active");
                String  storedPw = rs.getString("password");
                String  role     = rs.getString("role");

                if (!active) {
                    System.out.println("[Auth] Account is inactive: " + username);
                    return false;
                }

                if (PasswordUtil.verify(password, storedPw)) {
                    currentUser = new User(
                        rs.getInt("id"),
                        rs.getString("username"),
                        storedPw, role, active
                    );
                    loadProfile(conn, currentUser);
                    System.out.println("[Auth] Login OK: " + currentUser);
                    return true;
                }
            }
        } catch (SQLException e) {
            System.err.println("[Auth] Login error: " + e.getMessage());
        }
        return false;
    }

    /** Loads student or lecturer profile after login. */
    private static void loadProfile(Connection conn, User user) throws SQLException {
        if (user.isStudent()) {
            String sql = "SELECT * FROM students WHERE user_id = ?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, user.getId());
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    currentStudent = new Student(
                        rs.getInt("id"), user.getId(),
                        rs.getString("nim"), rs.getString("full_name"),
                        rs.getString("email"), rs.getString("phone"),
                        rs.getString("program")
                    );
                }
            }
        } else if (user.isLecturer()) {
            String sql = "SELECT * FROM lecturers WHERE user_id = ?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, user.getId());
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    currentLecturer = new Lecturer(
                        rs.getInt("id"), user.getId(),
                        rs.getString("nidn"), rs.getString("full_name"),
                        rs.getString("email"), rs.getString("phone"),
                        rs.getString("department")
                    );
                }
            }
        }
    }

    /** Log out and clear session. */
    public static void logout() {
        currentUser     = null;
        currentStudent  = null;
        currentLecturer = null;
        DatabaseConnection.closeConnection();
        System.out.println("[Auth] User logged out.");
    }

    // ── Session accessors ─────────────────────────────────────────────────────
    public static User     getCurrentUser()     { return currentUser; }
    public static Student  getCurrentStudent()  { return currentStudent; }
    public static Lecturer getCurrentLecturer() { return currentLecturer; }
    public static boolean  isLoggedIn()         { return currentUser != null; }
}
