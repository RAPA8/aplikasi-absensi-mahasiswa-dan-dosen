package studentattendance.controller;

import studentattendance.db.DatabaseConnection;
import studentattendance.model.*;
import studentattendance.util.PasswordUtil;

import java.sql.*;
import java.util.*;

/**
 * Admin-level CRUD operations.
 */
public class AdminController {

    // ── Students ──────────────────────────────────────────────────────────────
    public static List<Student> getAllStudents() throws SQLException {
        List<Student> list = new ArrayList<>();
        String sql = "SELECT s.*, u.username FROM students s JOIN users u ON s.user_id = u.id ORDER BY s.nim";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                list.add(new Student(rs.getInt("id"), rs.getInt("user_id"),
                    rs.getString("nim"), rs.getString("full_name"),
                    rs.getString("email"), rs.getString("phone"), rs.getString("program")));
            }
        }
        return list;
    }

    public static void addStudent(Student s, String password) throws SQLException {
        try (Connection conn = DatabaseConnection.getConnection()) {
            conn.setAutoCommit(false);
            try {
                String uSql = "INSERT INTO users (username, password, role) VALUES (?,?,?)";
                int userId;
                try (PreparedStatement ps = conn.prepareStatement(uSql, Statement.RETURN_GENERATED_KEYS)) {
                    ps.setString(1, s.getNim());
                    ps.setString(2, PasswordUtil.hash(password));
                    ps.setString(3, "STUDENT");
                    ps.executeUpdate();
                    ResultSet k = ps.getGeneratedKeys();
                    k.next();
                    userId = k.getInt(1);
                }
                String sSql = "INSERT INTO students (user_id,nim,full_name,email,phone,program) VALUES (?,?,?,?,?,?)";
                try (PreparedStatement ps = conn.prepareStatement(sSql)) {
                    ps.setInt(1, userId);
                    ps.setString(2, s.getNim());
                    ps.setString(3, s.getFullName());
                    ps.setString(4, s.getEmail());
                    ps.setString(5, s.getPhone());
                    ps.setString(6, s.getProgram());
                    ps.executeUpdate();
                }
                conn.commit();
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            } finally {
                conn.setAutoCommit(true);
            }
        }
    }

    public static void updateStudent(Student s) throws SQLException {
        String sql = "UPDATE students SET nim=?, full_name=?, email=?, phone=?, program=? WHERE id=?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, s.getNim());
            ps.setString(2, s.getFullName());
            ps.setString(3, s.getEmail());
            ps.setString(4, s.getPhone());
            ps.setString(5, s.getProgram());
            ps.setInt(6, s.getId());
            ps.executeUpdate();
        }
    }

    public static void deleteStudent(int studentId) throws SQLException {
        String sql = "DELETE FROM users WHERE id = (SELECT user_id FROM students WHERE id=?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            ps.executeUpdate();
        }
    }

    // ── Lecturers ─────────────────────────────────────────────────────────────
    public static List<Lecturer> getAllLecturers() throws SQLException {
        List<Lecturer> list = new ArrayList<>();
        String sql = "SELECT * FROM lecturers ORDER BY nidn";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                list.add(new Lecturer(rs.getInt("id"), rs.getInt("user_id"),
                    rs.getString("nidn"), rs.getString("full_name"),
                    rs.getString("email"), rs.getString("phone"), rs.getString("department")));
            }
        }
        return list;
    }

    // ── Courses ───────────────────────────────────────────────────────────────
    public static List<Course> getAllCourses() throws SQLException {
        List<Course> list = new ArrayList<>();
        String sql = "SELECT c.*, l.full_name as lecturer_name FROM courses c "
                   + "LEFT JOIN lecturers l ON c.lecturer_id = l.id ORDER BY c.course_code";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                list.add(new Course(rs.getInt("id"), rs.getString("course_code"),
                    rs.getString("course_name"), rs.getInt("credits"),
                    rs.getInt("lecturer_id"), rs.getString("lecturer_name")));
            }
        }
        return list;
    }

    public static void addCourse(Course c) throws SQLException {
        String sql = "INSERT INTO courses (course_code, course_name, credits, lecturer_id) VALUES (?,?,?,?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, c.getCourseCode());
            ps.setString(2, c.getCourseName());
            ps.setInt(3, c.getCredits());
            ps.setInt(4, c.getLecturerId());
            ps.executeUpdate();
        }
    }

    public static void deleteCourse(int courseId) throws SQLException {
        String sql = "DELETE FROM courses WHERE id=?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, courseId);
            ps.executeUpdate();
        }
    }

    // ── Schedules ─────────────────────────────────────────────────────────────
    public static List<Schedule> getAllSchedules() throws SQLException {
        List<Schedule> list = new ArrayList<>();
        String sql = "SELECT cs.*, c.course_code, c.course_name, l.full_name as lecturer_name "
                   + "FROM class_schedules cs "
                   + "JOIN courses c ON cs.course_id = c.id "
                   + "LEFT JOIN lecturers l ON c.lecturer_id = l.id "
                   + "ORDER BY FIELD(cs.day_of_week,'Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'), cs.start_time";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                Schedule s = new Schedule();
                s.setId(rs.getInt("id"));
                s.setCourseId(rs.getInt("course_id"));
                s.setCourseCode(rs.getString("course_code"));
                s.setCourseName(rs.getString("course_name"));
                s.setDayOfWeek(rs.getString("day_of_week"));
                s.setStartTime(rs.getString("start_time"));
                s.setEndTime(rs.getString("end_time"));
                s.setRoom(rs.getString("room"));
                s.setLecturerName(rs.getString("lecturer_name"));
                list.add(s);
            }
        }
        return list;
    }

    // ── Stats ─────────────────────────────────────────────────────────────────
    public static int countStudents() throws SQLException {
        return countTable("students");
    }

    public static int countLecturers() throws SQLException {
        return countTable("lecturers");
    }

    public static int countCourses() throws SQLException {
        return countTable("courses");
    }

    public static int countSessions() throws SQLException {
        return countTable("attendance_sessions");
    }

    private static int countTable(String table) throws SQLException {
        String sql = "SELECT COUNT(*) FROM " + table;
        try (Connection conn = DatabaseConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            return rs.next() ? rs.getInt(1) : 0;
        }
    }
}
