package studentattendance.controller;

import studentattendance.db.DatabaseConnection;
import studentattendance.model.*;

import java.sql.*;
import java.util.*;

/**
 * Lecturer-specific data operations.
 */
public class LecturerController {

    public static List<Course> getLecturerCourses(int lecturerId) throws SQLException {
        List<Course> list = new ArrayList<>();
        String sql = "SELECT c.*, l.full_name as lecturer_name FROM courses c "
                   + "LEFT JOIN lecturers l ON c.lecturer_id = l.id "
                   + "WHERE c.lecturer_id = ? ORDER BY c.course_code";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, lecturerId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Course(rs.getInt("id"), rs.getString("course_code"),
                    rs.getString("course_name"), rs.getInt("credits"),
                    rs.getInt("lecturer_id"), rs.getString("lecturer_name")));
            }
        }
        return list;
    }

    public static List<Schedule> getLecturerSchedule(int lecturerId) throws SQLException {
        List<Schedule> list = new ArrayList<>();
        String sql = "SELECT cs.*, c.course_code, c.course_name, l.full_name as lecturer_name "
                   + "FROM class_schedules cs "
                   + "JOIN courses c ON cs.course_id = c.id "
                   + "LEFT JOIN lecturers l ON c.lecturer_id = l.id "
                   + "WHERE c.lecturer_id = ? "
                   + "ORDER BY FIELD(cs.day_of_week,'Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'), cs.start_time";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, lecturerId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Schedule s = new Schedule();
                s.setId(rs.getInt("id"));
                s.setCourseId(rs.getInt("course_id"));
                s.setCourseCode(rs.getString("course_code"));
                s.setCourseName(rs.getString("course_name"));
                s.setDayOfWeek(rs.getString("day_of_week"));
                s.setStartTime(rs.getString("start_time"));
                s.setEndTime(rs.getString("end_time"));
                s.setRoom(rs.getString("room"));
                s.setLecturerName(rs.getString("lecturer_name"));
                list.add(s);
            }
        }
        return list;
    }

    public static List<LeaveRequest> getPendingLeaveRequests(int lecturerId) throws SQLException {
        List<LeaveRequest> list = new ArrayList<>();
        String sql = "SELECT lr.*, st.full_name as student_name, c.course_name "
                   + "FROM leave_requests lr "
                   + "JOIN students st ON lr.student_id = st.id "
                   + "JOIN courses c ON lr.course_id = c.id "
                   + "WHERE c.lecturer_id = ? AND lr.status = 'PENDING' "
                   + "ORDER BY lr.created_at DESC";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, lecturerId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                LeaveRequest lr = new LeaveRequest();
                lr.setId(rs.getInt("id"));
                lr.setStudentId(rs.getInt("student_id"));
                lr.setStudentName(rs.getString("student_name"));
                lr.setCourseId(rs.getInt("course_id"));
                lr.setCourseName(rs.getString("course_name"));
                lr.setRequestDate(rs.getDate("request_date").toLocalDate());
                lr.setReason(rs.getString("reason"));
                lr.setType(rs.getString("type"));
                lr.setStatus(rs.getString("status"));
                list.add(lr);
            }
        }
        return list;
    }

    public static void processLeaveRequest(int requestId, String status, String note) throws SQLException {
        String sql = "UPDATE leave_requests SET status=?, lecturer_note=? WHERE id=?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setString(2, note);
            ps.setInt(3, requestId);
            ps.executeUpdate();
        }
    }
}
