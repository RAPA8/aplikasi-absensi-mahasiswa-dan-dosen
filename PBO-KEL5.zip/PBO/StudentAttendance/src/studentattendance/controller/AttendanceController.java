package studentattendance.controller;

import studentattendance.db.DatabaseConnection;
import studentattendance.model.*;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

/**
 * Handles all attendance-related operations.
 */
public class AttendanceController {

    // ── Open a new attendance session (Lecturer) ───────────────────────────────
    public static AttendanceSession openSession(int courseId, int lecturerId) throws SQLException {
        String code = generateCode();
        String sql  = "INSERT INTO attendance_sessions "
                    + "(course_id, lecturer_id, session_date, open_time, attendance_code, qr_data, status) "
                    + "VALUES (?, ?, ?, ?, ?, ?, 'OPEN')";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            LocalDate     today = LocalDate.now();
            LocalDateTime now   = LocalDateTime.now();

            ps.setInt(1, courseId);
            ps.setInt(2, lecturerId);
            ps.setDate(3, Date.valueOf(today));
            ps.setTimestamp(4, Timestamp.valueOf(now));
            ps.setString(5, code);
            ps.setString(6, "ATTEND:" + code + ":" + courseId + ":" + today);
            ps.executeUpdate();

            ResultSet keys = ps.getGeneratedKeys();
            if (keys.next()) {
                AttendanceSession session = new AttendanceSession();
                session.setId(keys.getInt(1));
                session.setCourseId(courseId);
                session.setLecturerId(lecturerId);
                session.setSessionDate(today);
                session.setOpenTime(now);
                session.setAttendanceCode(code);
                session.setQrData("ATTEND:" + code + ":" + courseId + ":" + today);
                session.setStatus("OPEN");
                return session;
            }
        }
        throw new SQLException("Failed to create attendance session.");
    }

    /** Close an attendance session. */
    public static void closeSession(int sessionId) throws SQLException {
        String sql = "UPDATE attendance_sessions SET status='CLOSED', close_time=? WHERE id=?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setTimestamp(1, Timestamp.valueOf(LocalDateTime.now()));
            ps.setInt(2, sessionId);
            ps.executeUpdate();
        }
    }

    // ── Student marks attendance ───────────────────────────────────────────────
    public static String submitAttendance(int studentId, String code) throws SQLException {
        // Find open session with this code
        String findSql = "SELECT id, course_id, status FROM attendance_sessions "
                       + "WHERE attendance_code = ? AND status = 'OPEN'";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(findSql)) {
            ps.setString(1, code.trim().toUpperCase());
            ResultSet rs = ps.executeQuery();

            if (!rs.next()) return "INVALID_CODE";

            int sessionId = rs.getInt("id");
            int courseId  = rs.getInt("course_id");

            // Check enrollment
            String enrollSql = "SELECT id FROM student_courses WHERE student_id=? AND course_id=?";
            try (PreparedStatement ep = conn.prepareStatement(enrollSql)) {
                ep.setInt(1, studentId);
                ep.setInt(2, courseId);
                ResultSet er = ep.executeQuery();
                if (!er.next()) return "NOT_ENROLLED";
            }

            // Check duplicate
            String dupSql = "SELECT id FROM attendance_records WHERE session_id=? AND student_id=?";
            try (PreparedStatement dp = conn.prepareStatement(dupSql)) {
                dp.setInt(1, sessionId);
                dp.setInt(2, studentId);
                ResultSet dr = dp.executeQuery();
                if (dr.next()) return "ALREADY_MARKED";
            }

            // Insert record
            String insertSql = "INSERT INTO attendance_records (session_id, student_id, check_in, status) VALUES (?,?,?,?)";
            try (PreparedStatement ip = conn.prepareStatement(insertSql)) {
                ip.setInt(1, sessionId);
                ip.setInt(2, studentId);
                ip.setTimestamp(3, Timestamp.valueOf(LocalDateTime.now()));
                ip.setString(4, "PRESENT");
                ip.executeUpdate();
            }
            return "SUCCESS";
        }
    }

    // ── Get open sessions for a lecturer ──────────────────────────────────────
    public static List<AttendanceSession> getOpenSessions(int lecturerId) throws SQLException {
        List<AttendanceSession> list = new ArrayList<>();
        String sql = "SELECT s.*, c.course_name FROM attendance_sessions s "
                   + "JOIN courses c ON s.course_id = c.id "
                   + "WHERE s.lecturer_id = ? AND s.status = 'OPEN' "
                   + "ORDER BY s.open_time DESC";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, lecturerId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                AttendanceSession sess = mapSession(rs);
                list.add(sess);
            }
        }
        return list;
    }

    // ── Get all sessions for a lecturer (history) ─────────────────────────────
    public static List<AttendanceSession> getLecturerSessions(int lecturerId) throws SQLException {
        List<AttendanceSession> list = new ArrayList<>();
        String sql = "SELECT s.*, c.course_name FROM attendance_sessions s "
                   + "JOIN courses c ON s.course_id = c.id "
                   + "WHERE s.lecturer_id = ? ORDER BY s.session_date DESC LIMIT 50";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, lecturerId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapSession(rs));
        }
        return list;
    }

    // ── Get records for a session ─────────────────────────────────────────────
    public static List<AttendanceRecord> getSessionRecords(int sessionId) throws SQLException {
        List<AttendanceRecord> list = new ArrayList<>();
        String sql = "SELECT ar.*, st.full_name, st.nim, c.course_name "
                   + "FROM attendance_records ar "
                   + "JOIN students st ON ar.student_id = st.id "
                   + "JOIN attendance_sessions s ON ar.session_id = s.id "
                   + "JOIN courses c ON s.course_id = c.id "
                   + "WHERE ar.session_id = ? ORDER BY st.full_name";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, sessionId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapRecord(rs));
        }
        return list;
    }

    // ── Get attendance history for a student ──────────────────────────────────
    public static List<AttendanceRecord> getStudentHistory(int studentId) throws SQLException {
        List<AttendanceRecord> list = new ArrayList<>();
        String sql = "SELECT ar.*, st.full_name, st.nim, c.course_name "
                   + "FROM attendance_records ar "
                   + "JOIN students st ON ar.student_id = st.id "
                   + "JOIN attendance_sessions s ON ar.session_id = s.id "
                   + "JOIN courses c ON s.course_id = c.id "
                   + "WHERE ar.student_id = ? ORDER BY ar.check_in DESC LIMIT 100";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapRecord(rs));
        }
        return list;
    }

    // ── Get attendance % per course for a student ─────────────────────────────
    public static Map<String, double[]> getStudentAttendanceStats(int studentId) throws SQLException {
        Map<String, double[]> stats = new LinkedHashMap<>();
        String sql = "SELECT c.course_name, "
                   + "COUNT(ar.id) as attended, "
                   + "(SELECT COUNT(*) FROM attendance_sessions s2 WHERE s2.course_id = c.id) as total "
                   + "FROM student_courses sc "
                   + "JOIN courses c ON sc.course_id = c.id "
                   + "LEFT JOIN attendance_sessions s ON s.course_id = c.id "
                   + "LEFT JOIN attendance_records ar ON ar.session_id = s.id "
                   + "  AND ar.student_id = sc.student_id AND ar.status IN ('PRESENT','LATE','EXCUSED') "
                   + "WHERE sc.student_id = ? "
                   + "GROUP BY c.id, c.course_name";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                double attended = rs.getDouble("attended");
                double total    = rs.getDouble("total");
                double pct      = (total > 0) ? (attended / total * 100.0) : 0.0;
                stats.put(rs.getString("course_name"), new double[]{attended, total, pct});
            }
        }
        return stats;
    }

    // ── Update a single record status (Lecturer edit) ─────────────────────────
    public static void updateRecordStatus(int recordId, String status, String note) throws SQLException {
        String sql = "UPDATE attendance_records SET status=?, note=? WHERE id=?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setString(2, note);
            ps.setInt(3, recordId);
            ps.executeUpdate();
        }
    }

    // ── Recap: all students for a course ──────────────────────────────────────
    public static List<Object[]> getCourseAttendanceRecap(int courseId) throws SQLException {
        List<Object[]> rows = new ArrayList<>();
        String sql = "SELECT st.nim, st.full_name, "
                   + "SUM(CASE WHEN ar.status='PRESENT' THEN 1 ELSE 0 END) as present_count, "
                   + "SUM(CASE WHEN ar.status='LATE'    THEN 1 ELSE 0 END) as late_count, "
                   + "SUM(CASE WHEN ar.status='EXCUSED' THEN 1 ELSE 0 END) as excused_count, "
                   + "SUM(CASE WHEN ar.status='ABSENT'  THEN 1 ELSE 0 END) as absent_count, "
                   + "COUNT(DISTINCT s.id) as total_sessions "
                   + "FROM student_courses sc "
                   + "JOIN students st ON sc.student_id = st.id "
                   + "LEFT JOIN attendance_sessions s  ON s.course_id = sc.course_id "
                   + "LEFT JOIN attendance_records  ar ON ar.session_id = s.id AND ar.student_id = sc.student_id "
                   + "WHERE sc.course_id = ? "
                   + "GROUP BY st.id, st.nim, st.full_name ORDER BY st.full_name";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, courseId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                int present = rs.getInt("present_count");
                int late    = rs.getInt("late_count");
                int excused = rs.getInt("excused_count");
                int absent  = rs.getInt("absent_count");
                int total   = rs.getInt("total_sessions");
                double pct  = total > 0 ? ((present + late + excused) * 100.0 / total) : 0.0;
                rows.add(new Object[]{
                    rs.getString("nim"),
                    rs.getString("full_name"),
                    present, late, excused, absent, total,
                    String.format("%.1f%%", pct)
                });
            }
        }
        return rows;
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    private static String generateCode() {
        String chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
        StringBuilder sb = new StringBuilder();
        Random rng = new Random();
        for (int i = 0; i < 6; i++) sb.append(chars.charAt(rng.nextInt(chars.length())));
        return sb.toString();
    }

    private static AttendanceSession mapSession(ResultSet rs) throws SQLException {
        AttendanceSession s = new AttendanceSession();
        s.setId(rs.getInt("id"));
        s.setCourseId(rs.getInt("course_id"));
        s.setCourseName(rs.getString("course_name"));
        s.setLecturerId(rs.getInt("lecturer_id"));
        s.setSessionDate(rs.getDate("session_date").toLocalDate());
        s.setOpenTime(rs.getTimestamp("open_time").toLocalDateTime());
        Timestamp ct = rs.getTimestamp("close_time");
        if (ct != null) s.setCloseTime(ct.toLocalDateTime());
        s.setAttendanceCode(rs.getString("attendance_code"));
        s.setQrData(rs.getString("qr_data"));
        s.setStatus(rs.getString("status"));
        return s;
    }

    private static AttendanceRecord mapRecord(ResultSet rs) throws SQLException {
        AttendanceRecord r = new AttendanceRecord();
        r.setId(rs.getInt("id") );
        r.setSessionId(rs.getInt("session_id"));
        r.setStudentId(rs.getInt("student_id"));
        r.setStudentName(rs.getString("full_name"));
        r.setNim(rs.getString("nim"));
        r.setCourseName(rs.getString("course_name"));
        Timestamp ci = rs.getTimestamp("check_in");
        if (ci != null) r.setCheckIn(ci.toLocalDateTime());
        r.setStatus(rs.getString("status"));
        r.setNote(rs.getString("note"));
        return r;
    }
}
