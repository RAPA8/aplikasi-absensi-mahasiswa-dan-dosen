package studentattendance.controller;

import studentattendance.db.DatabaseConnection;
import studentattendance.model.*;

import java.sql.*;
import java.util.*;

/**
 * Student-specific data operations.
 */
public class StudentController {

    public static List<Course> getEnrolledCourses(int studentId) throws SQLException {
        List<Course> list = new ArrayList<>();
        String sql = "SELECT c.*, l.full_name as lecturer_name "
                   + "FROM student_courses sc "
                   + "JOIN courses c ON sc.course_id = c.id "
                   + "LEFT JOIN lecturers l ON c.lecturer_id = l.id "
                   + "WHERE sc.student_id = ? ORDER BY c.course_code";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Course(rs.getInt("id"), rs.getString("course_code"),
                    rs.getString("course_name"), rs.getInt("credits"),
                    rs.getInt("lecturer_id"), rs.getString("lecturer_name")));
            }
        }
        return list;
    }

    public static List<Schedule> getSchedule(int studentId) throws SQLException {
        List<Schedule> list = new ArrayList<>();
        String sql = "SELECT cs.*, c.course_code, c.course_name, l.full_name as lecturer_name "
                   + "FROM student_courses sc "
                   + "JOIN class_schedules cs ON sc.course_id = cs.course_id "
                   + "JOIN courses c ON cs.course_id = c.id "
                   + "LEFT JOIN lecturers l ON c.lecturer_id = l.id "
                   + "WHERE sc.student_id = ? "
                   + "ORDER BY FIELD(cs.day_of_week,'Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'), cs.start_time";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Schedule s = new Schedule();
                s.setId(rs.getInt("id"));
                s.setCourseId(rs.getInt("course_id"));
                s.setCourseCode(rs.getString("course_code"));
                s.setCourseName(rs.getString("course_name"));
                s.setDayOfWeek(rs.getString("day_of_week"));
                s.setStartTime(rs.getString("start_time"));
                s.setEndTime(rs.getString("end_time"));
                s.setRoom(rs.getString("room"));
                s.setLecturerName(rs.getString("lecturer_name"));
                list.add(s);
            }
        }
        return list;
    }

    public static void submitLeaveRequest(LeaveRequest req) throws SQLException {
        String sql = "INSERT INTO leave_requests "
                   + "(student_id, course_id, session_id, request_date, reason, type, status) "
                   + "VALUES (?,?,?,?,?,?,'PENDING')";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, req.getStudentId());
            ps.setInt(2, req.getCourseId());
            if (req.getSessionId() != null) ps.setInt(3, req.getSessionId());
            else ps.setNull(3, Types.INTEGER);
            ps.setDate(4, Date.valueOf(req.getRequestDate()));
            ps.setString(5, req.getReason());
            ps.setString(6, req.getType());
            ps.executeUpdate();
        }
    }

    public static List<LeaveRequest> getLeaveRequests(int studentId) throws SQLException {
        List<LeaveRequest> list = new ArrayList<>();
        String sql = "SELECT lr.*, c.course_name FROM leave_requests lr "
                   + "JOIN courses c ON lr.course_id = c.id "
                   + "WHERE lr.student_id = ? ORDER BY lr.created_at DESC";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                LeaveRequest lr = new LeaveRequest();
                lr.setId(rs.getInt("id"));
                lr.setStudentId(studentId);
                lr.setCourseId(rs.getInt("course_id"));
                lr.setCourseName(rs.getString("course_name"));
                lr.setRequestDate(rs.getDate("request_date").toLocalDate());
                lr.setReason(rs.getString("reason"));
                lr.setType(rs.getString("type"));
                lr.setStatus(rs.getString("status"));
                lr.setLecturerNote(rs.getString("lecturer_note"));
                list.add(lr);
            }
        }
        return list;
    }
}
