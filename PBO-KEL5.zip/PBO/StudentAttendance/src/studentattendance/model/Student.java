package studentattendance.model;

/**
 * Represents a Student entity.
 */
public class Student {
    private int    id;
    private int    userId;
    private String nim;
    private String fullName;
    private String email;
    private String phone;
    private String program;

    public Student() {}

    public Student(int id, int userId, String nim, String fullName,
                   String email, String phone, String program) {
        this.id       = id;
        this.userId   = userId;
        this.nim      = nim;
        this.fullName = fullName;
        this.email    = email;
        this.phone    = phone;
        this.program  = program;
    }

    // ── Getters & Setters ──────────────────────────────────────────────────────
    public int    getId()                  { return id; }
    public void   setId(int id)            { this.id = id; }

    public int    getUserId()              { return userId; }
    public void   setUserId(int uid)       { this.userId = uid; }

    public String getNim()                 { return nim; }
    public void   setNim(String nim)       { this.nim = nim; }

    public String getFullName()            { return fullName; }
    public void   setFullName(String fn)   { this.fullName = fn; }

    public String getEmail()               { return email; }
    public void   setEmail(String e)       { this.email = e; }

    public String getPhone()               { return phone; }
    public void   setPhone(String p)       { this.phone = p; }

    public String getProgram()             { return program; }
    public void   setProgram(String pr)    { this.program = pr; }

    @Override public String toString() { return fullName + " (" + nim + ")"; }
}
