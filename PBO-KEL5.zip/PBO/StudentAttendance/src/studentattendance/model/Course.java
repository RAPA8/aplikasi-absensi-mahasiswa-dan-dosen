package studentattendance.model;

/**
 * Represents a Course / Subject.
 */
public class Course {
    private int    id;
    private String courseCode;
    private String courseName;
    private int    credits;
    private int    lecturerId;
    private String lecturerName;  // joined field for display

    public Course() {}

    public Course(int id, String courseCode, String courseName,
                  int credits, int lecturerId, String lecturerName) {
        this.id           = id;
        this.courseCode   = courseCode;
        this.courseName   = courseName;
        this.credits      = credits;
        this.lecturerId   = lecturerId;
        this.lecturerName = lecturerName;
    }

    // ── Getters & Setters ──────────────────────────────────────────────────────
    public int    getId()                      { return id; }
    public void   setId(int id)                { this.id = id; }

    public String getCourseCode()              { return courseCode; }
    public void   setCourseCode(String c)      { this.courseCode = c; }

    public String getCourseName()              { return courseName; }
    public void   setCourseName(String n)      { this.courseName = n; }

    public int    getCredits()                 { return credits; }
    public void   setCredits(int cr)           { this.credits = cr; }

    public int    getLecturerId()              { return lecturerId; }
    public void   setLecturerId(int lid)       { this.lecturerId = lid; }

    public String getLecturerName()            { return lecturerName; }
    public void   setLecturerName(String ln)   { this.lecturerName = ln; }

    @Override public String toString() { return courseCode + " - " + courseName; }
}
