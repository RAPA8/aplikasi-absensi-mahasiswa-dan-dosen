package studentattendance.model;

/**
 * Represents a weekly class schedule entry.
 */
public class Schedule {
    private int    id;
    private int    courseId;
    private String courseCode;
    private String courseName;
    private String dayOfWeek;
    private String startTime;
    private String endTime;
    private String room;
    private String lecturerName;

    public Schedule() {}

    // ── Getters & Setters ──────────────────────────────────────────────────────
    public int    getId()                      { return id; }
    public void   setId(int id)                { this.id = id; }

    public int    getCourseId()                { return courseId; }
    public void   setCourseId(int cid)         { this.courseId = cid; }

    public String getCourseCode()              { return courseCode; }
    public void   setCourseCode(String c)      { this.courseCode = c; }

    public String getCourseName()              { return courseName; }
    public void   setCourseName(String cn)     { this.courseName = cn; }

    public String getDayOfWeek()               { return dayOfWeek; }
    public void   setDayOfWeek(String d)       { this.dayOfWeek = d; }

    public String getStartTime()               { return startTime; }
    public void   setStartTime(String st)      { this.startTime = st; }

    public String getEndTime()                 { return endTime; }
    public void   setEndTime(String et)        { this.endTime = et; }

    public String getRoom()                    { return room; }
    public void   setRoom(String r)            { this.room = r; }

    public String getLecturerName()            { return lecturerName; }
    public void   setLecturerName(String ln)   { this.lecturerName = ln; }

    @Override public String toString() {
        return dayOfWeek + " " + startTime + "-" + endTime + " | " + courseName + " @ " + room;
    }
}
