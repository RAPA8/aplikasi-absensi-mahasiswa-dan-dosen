package studentattendance.model;

import java.time.LocalDate;

/**
 * A leave / absence request submitted by a student.
 */
public class LeaveRequest {
    private int       id;
    private int       studentId;
    private String    studentName;  // joined
    private int       courseId;
    private String    courseName;   // joined
    private Integer   sessionId;
    private LocalDate requestDate;
    private String    reason;
    private String    type;         // SICK | PERMISSION | OTHER
    private String    status;       // PENDING | APPROVED | REJECTED
    private String    lecturerNote;

    public LeaveRequest() {}

    // ── Getters & Setters ──────────────────────────────────────────────────────
    public int       getId()                       { return id; }
    public void      setId(int id)                 { this.id = id; }

    public int       getStudentId()                { return studentId; }
    public void      setStudentId(int sid)         { this.studentId = sid; }

    public String    getStudentName()              { return studentName; }
    public void      setStudentName(String sn)     { this.studentName = sn; }

    public int       getCourseId()                 { return courseId; }
    public void      setCourseId(int cid)          { this.courseId = cid; }

    public String    getCourseName()               { return courseName; }
    public void      setCourseName(String cn)      { this.courseName = cn; }

    public Integer   getSessionId()                { return sessionId; }
    public void      setSessionId(Integer sid)     { this.sessionId = sid; }

    public LocalDate getRequestDate()              { return requestDate; }
    public void      setRequestDate(LocalDate d)   { this.requestDate = d; }

    public String    getReason()                   { return reason; }
    public void      setReason(String r)           { this.reason = r; }

    public String    getType()                     { return type; }
    public void      setType(String t)             { this.type = t; }

    public String    getStatus()                   { return status; }
    public void      setStatus(String s)           { this.status = s; }

    public String    getLecturerNote()             { return lecturerNote; }
    public void      setLecturerNote(String ln)    { this.lecturerNote = ln; }

    @Override public String toString() {
        return type + " request by " + studentName + " [" + status + "]";
    }
}
