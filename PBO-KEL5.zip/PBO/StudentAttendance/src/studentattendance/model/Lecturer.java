package studentattendance.model;

/**
 * Represents a Lecturer entity.
 */
public class Lecturer {
    private int    id;
    private int    userId;
    private String nidn;
    private String fullName;
    private String email;
    private String phone;
    private String department;

    public Lecturer() {}

    public Lecturer(int id, int userId, String nidn, String fullName,
                    String email, String phone, String department) {
        this.id         = id;
        this.userId     = userId;
        this.nidn       = nidn;
        this.fullName   = fullName;
        this.email      = email;
        this.phone      = phone;
        this.department = department;
    }

    // ── Getters & Setters ──────────────────────────────────────────────────────
    public int    getId()                  { return id; }
    public void   setId(int id)            { this.id = id; }

    public int    getUserId()              { return userId; }
    public void   setUserId(int uid)       { this.userId = uid; }

    public String getNidn()                { return nidn; }
    public void   setNidn(String nidn)     { this.nidn = nidn; }

    public String getFullName()            { return fullName; }
    public void   setFullName(String fn)   { this.fullName = fn; }

    public String getEmail()               { return email; }
    public void   setEmail(String e)       { this.email = e; }

    public String getPhone()               { return phone; }
    public void   setPhone(String p)       { this.phone = p; }

    public String getDepartment()          { return department; }
    public void   setDepartment(String d)  { this.department = d; }

    @Override public String toString() { return fullName + " (" + nidn + ")"; }
}
