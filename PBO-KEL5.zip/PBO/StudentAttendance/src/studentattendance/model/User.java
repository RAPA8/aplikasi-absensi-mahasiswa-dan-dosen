package studentattendance.model;

/**
 * Represents a login user with role information.
 */
public class User {
    private int    id;
    private String username;
    private String password;
    private String role;      // STUDENT | LECTURER | ADMIN
    private boolean active;

    public User() {}

    public User(int id, String username, String password, String role, boolean active) {
        this.id       = id;
        this.username = username;
        this.password = password;
        this.role     = role;
        this.active   = active;
    }

    // ── Getters & Setters ──────────────────────────────────────────────────────
    public int     getId()       { return id; }
    public void    setId(int id) { this.id = id; }

    public String  getUsername()            { return username; }
    public void    setUsername(String u)    { this.username = u; }

    public String  getPassword()            { return password; }
    public void    setPassword(String p)    { this.password = p; }

    public String  getRole()                { return role; }
    public void    setRole(String r)        { this.role = r; }

    public boolean isActive()               { return active; }
    public void    setActive(boolean a)     { this.active = a; }

    public boolean isStudent()   { return "STUDENT".equals(role); }
    public boolean isLecturer()  { return "LECTURER".equals(role); }
    public boolean isAdmin()     { return "ADMIN".equals(role); }

    @Override public String toString() {
        return "User{id=" + id + ", username='" + username + "', role='" + role + "'}";
    }
}
