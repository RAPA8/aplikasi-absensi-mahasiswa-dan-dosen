package studentattendance.model;

import java.time.LocalDateTime;

/**
 * A single student attendance record within a session.
 */
public class AttendanceRecord {
    private int           id;
    private int           sessionId;
    private int           studentId;
    private String        studentName;   // joined
    private String        nim;           // joined
    private String        courseName;    // joined
    private LocalDateTime checkIn;
    private String        status;        // PRESENT | ABSENT | LATE | EXCUSED
    private String        note;

    public AttendanceRecord() {}

    // ── Getters & Setters ──────────────────────────────────────────────────────
    public int           getId()                        { return id; }
    public void          setId(int id)                  { this.id = id; }

    public int           getSessionId()                 { return sessionId; }
    public void          setSessionId(int sid)          { this.sessionId = sid; }

    public int           getStudentId()                 { return studentId; }
    public void          setStudentId(int sid)          { this.studentId = sid; }

    public String        getStudentName()               { return studentName; }
    public void          setStudentName(String sn)      { this.studentName = sn; }

    public String        getNim()                       { return nim; }
    public void          setNim(String nim)             { this.nim = nim; }

    public String        getCourseName()                { return courseName; }
    public void          setCourseName(String cn)       { this.courseName = cn; }

    public LocalDateTime getCheckIn()                   { return checkIn; }
    public void          setCheckIn(LocalDateTime ci)   { this.checkIn = ci; }

    public String        getStatus()                    { return status; }
    public void          setStatus(String s)            { this.status = s; }

    public String        getNote()                      { return note; }
    public void          setNote(String n)              { this.note = n; }

    @Override public String toString() {
        return studentName + " - " + status;
    }
}
