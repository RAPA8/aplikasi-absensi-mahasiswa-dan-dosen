package studentattendance.model;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Attendance session opened by a lecturer.
 */
public class AttendanceSession {
    private int           id;
    private int           courseId;
    private String        courseName;    // joined
    private int           lecturerId;
    private LocalDate     sessionDate;
    private LocalDateTime openTime;
    private LocalDateTime closeTime;
    private String        attendanceCode;
    private String        qrData;
    private String        status;        // OPEN | CLOSED

    public AttendanceSession() {}

    // ── Getters & Setters ──────────────────────────────────────────────────────
    public int           getId()                      { return id; }
    public void          setId(int id)                { this.id = id; }

    public int           getCourseId()                { return courseId; }
    public void          setCourseId(int cid)         { this.courseId = cid; }

    public String        getCourseName()              { return courseName; }
    public void          setCourseName(String cn)     { this.courseName = cn; }

    public int           getLecturerId()              { return lecturerId; }
    public void          setLecturerId(int lid)       { this.lecturerId = lid; }

    public LocalDate     getSessionDate()             { return sessionDate; }
    public void          setSessionDate(LocalDate d)  { this.sessionDate = d; }

    public LocalDateTime getOpenTime()                { return openTime; }
    public void          setOpenTime(LocalDateTime t) { this.openTime = t; }

    public LocalDateTime getCloseTime()               { return closeTime; }
    public void          setCloseTime(LocalDateTime t){ this.closeTime = t; }

    public String        getAttendanceCode()          { return attendanceCode; }
    public void          setAttendanceCode(String c)  { this.attendanceCode = c; }

    public String        getQrData()                  { return qrData; }
    public void          setQrData(String q)          { this.qrData = q; }

    public String        getStatus()                  { return status; }
    public void          setStatus(String s)          { this.status = s; }

    public boolean isOpen() { return "OPEN".equals(status); }

    @Override public String toString() {
        return courseName + " [" + sessionDate + "] Code:" + attendanceCode;
    }
}
