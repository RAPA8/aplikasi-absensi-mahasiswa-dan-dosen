package studentattendance.view;

import studentattendance.controller.*;
import studentattendance.model.*;
import studentattendance.util.UITheme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

/**
 * Admin Dashboard — manage students, lecturers, courses, schedules.
 */
public class AdminDashboard extends JFrame {

    private JPanel    contentPanel;
    private CardLayout cardLayout;

    public AdminDashboard() {
        UITheme.applyTheme();
        setTitle("AbsenDulu — Admin Dashboard");
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) { doLogout(); }
        });
        setSize(1200, 720);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        add(buildSidebar(), BorderLayout.WEST);
        add(buildContent(), BorderLayout.CENTER);
        showPanel("HOME");
        setVisible(true);
    }

    // ── Sidebar ───────────────────────────────────────────────────────────────
    private JPanel buildSidebar() {
        JPanel sidebar = UITheme.sidebarPanel();
        sidebar.setPreferredSize(new Dimension(230, 720));
        sidebar.setLayout(null);

        JLabel avatar = new JLabel("🛡️", SwingConstants.CENTER);
        avatar.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 42));
        avatar.setBounds(0, 20, 230, 50);

        JLabel name = new JLabel("Administrator", SwingConstants.CENTER);
        name.setFont(UITheme.FONT_SUB);
        name.setForeground(UITheme.BEIGE_LIGHT);
        name.setBounds(0, 72, 230, 22);

        JLabel role = new JLabel("System Admin", SwingConstants.CENTER);
        role.setFont(UITheme.FONT_SMALL);
        role.setForeground(new Color(0xCCCCBB));
        role.setBounds(0, 94, 230, 18);

        JSeparator sep = new JSeparator();
        sep.setBounds(20, 122, 190, 1);
        sep.setForeground(new Color(0x7A8344));

        sidebar.add(avatar); sidebar.add(name); sidebar.add(role); sidebar.add(sep);

        String[][] menus = {
            {"🏠", "Overview",   "HOME"},
            {"👥", "Students",   "STUDENTS"},
            {"👨‍🏫", "Lecturers",  "LECTURERS"},
            {"📚", "Courses",    "COURSES"},
            {"📅", "Schedules",  "SCHEDULES"},
        };
        int y = 136;
        for (String[] m : menus) {
            sidebar.add(navBtn(m[0]+"  "+m[1], m[2], y));
            y += 52;
        }

        JButton btnLogout = new JButton("⏏  Logout");
        btnLogout.setFont(UITheme.FONT_BUTTON);
        btnLogout.setForeground(new Color(0xFFAAAA));
        btnLogout.setContentAreaFilled(false);
        btnLogout.setBorderPainted(false);
        btnLogout.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnLogout.setBounds(10, 660, 210, 40);
        btnLogout.addActionListener(e -> doLogout());
        sidebar.add(btnLogout);
        return sidebar;
    }

    private JButton navBtn(String label, String panel, int y) {
        JButton btn = new JButton(label) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (getModel().isRollover() || getModel().isPressed()) {
                    g2.setColor(new Color(255,255,255,30));
                    g2.fillRoundRect(0,0,getWidth(),getHeight(),10,10);
                }
                g2.setColor(UITheme.BEIGE_LIGHT);
                g2.setFont(getFont());
                g2.drawString(getText(), 20, getHeight()/2+5);
                g2.dispose();
            }
        };
        btn.setFont(UITheme.FONT_BODY);
        btn.setBounds(10, y, 210, 42);
        btn.setBorderPainted(false); btn.setContentAreaFilled(false);
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.addActionListener(e -> showPanel(panel));
        return btn;
    }

    private JPanel buildContent() {
        cardLayout   = new CardLayout();
        contentPanel = new JPanel(cardLayout);
        contentPanel.setBackground(UITheme.BEIGE_LIGHT);
        contentPanel.add(buildHome(),      "HOME");
        contentPanel.add(buildStudents(),  "STUDENTS");
        contentPanel.add(buildLecturers(), "LECTURERS");
        contentPanel.add(buildCourses(),   "COURSES");
        contentPanel.add(buildSchedules(), "SCHEDULES");
        return contentPanel;
    }

    private void showPanel(String n) { cardLayout.show(contentPanel, n); }

    // ── Overview ──────────────────────────────────────────────────────────────
    private JPanel buildHome() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(UITheme.BEIGE_LIGHT);
        p.setBorder(new EmptyBorder(30,30,30,30));

        JLabel title = new JLabel("System Overview");
        title.setFont(UITheme.FONT_TITLE);
        title.setForeground(UITheme.ARMY_GREEN_DARK);
        p.add(title, BorderLayout.NORTH);

        JPanel cards = new JPanel(new GridLayout(1,4,16,16));
        cards.setOpaque(false);
        cards.setBorder(new EmptyBorder(20,0,0,0));

        String[] icons  = {"👥","👨‍🏫","📚","📋"};
        String[] labels = {"Students","Lecturers","Courses","Sessions"};
        JLabel[] vals   = new JLabel[4];
        Color[]  colors = {UITheme.ARMY_GREEN, UITheme.INFO, UITheme.SUCCESS, UITheme.WARNING};

        for (int i = 0; i < 4; i++) {
            JPanel card = UITheme.card();
            card.setLayout(new BorderLayout());
            JLabel ic = new JLabel(icons[i], SwingConstants.CENTER);
            ic.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 36));
            vals[i] = new JLabel("...", SwingConstants.CENTER);
            vals[i].setFont(new Font("Segoe UI", Font.BOLD, 36));
            vals[i].setForeground(colors[i]);
            JLabel lbl = new JLabel(labels[i], SwingConstants.CENTER);
            lbl.setFont(UITheme.FONT_BODY);
            lbl.setForeground(UITheme.TEXT_MUTED);
            card.add(ic, BorderLayout.NORTH);
            card.add(vals[i], BorderLayout.CENTER);
            card.add(lbl, BorderLayout.SOUTH);
            cards.add(card);
        }
        p.add(cards, BorderLayout.CENTER);

        SwingWorker<int[],Void> w = new SwingWorker<>() {
            @Override protected int[] doInBackground() throws Exception {
                return new int[]{
                    AdminController.countStudents(),
                    AdminController.countLecturers(),
                    AdminController.countCourses(),
                    AdminController.countSessions()
                };
            }
            @Override protected void done() {
                try {
                    int[] v = get();
                    for (int i=0; i<4; i++) vals[i].setText(String.valueOf(v[i]));
                } catch (Exception ignored) {}
            }
        };
        w.execute();
        return p;
    }

    // ── Students ──────────────────────────────────────────────────────────────
    private JPanel buildStudents() {
        JPanel p = new JPanel(new BorderLayout(0,12));
        p.setBackground(UITheme.BEIGE_LIGHT);
        p.setBorder(new EmptyBorder(30,30,30,30));

        JLabel title = new JLabel("Manage Students");
        title.setFont(UITheme.FONT_TITLE);
        title.setForeground(UITheme.ARMY_GREEN_DARK);
        p.add(title, BorderLayout.NORTH);

        String[] cols = {"ID","NIM","Full Name","Email","Phone","Program"};
        DefaultTableModel model = new DefaultTableModel(cols,0){
            @Override public boolean isCellEditable(int r,int c){return false;}
        };
        JTable table = styledTable(model);
        JScrollPane scroll = new JScrollPane(table);

        JPanel btns = new JPanel(new FlowLayout(FlowLayout.LEFT,8,0));
        btns.setOpaque(false);
        JButton btnAdd    = UITheme.primaryButton("➕ Add Student");
        JButton btnEdit   = UITheme.secondaryButton("✏️ Edit");
        JButton btnDelete = UITheme.dangerButton("🗑️ Delete");
        JButton btnRefresh= UITheme.secondaryButton("🔄 Refresh");
        btns.add(btnAdd); btns.add(btnEdit); btns.add(btnDelete); btns.add(btnRefresh);

        loadStudents(model);

        btnRefresh.addActionListener(e -> loadStudents(model));

        btnAdd.addActionListener(e -> showAddStudentDialog(model));

        btnEdit.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) { UITheme.showError(p,"Select a student to edit."); return; }
            Student s = new Student();
            s.setId((int)model.getValueAt(row,0));
            s.setNim((String)model.getValueAt(row,1));
            s.setFullName((String)model.getValueAt(row,2));
            s.setEmail((String)model.getValueAt(row,3));
            s.setPhone((String)model.getValueAt(row,4));
            s.setProgram((String)model.getValueAt(row,5));
            showEditStudentDialog(s, model);
        });

        btnDelete.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) { UITheme.showError(p,"Select a student to delete."); return; }
            int id = (int)model.getValueAt(row,0);
            if (!UITheme.confirm(p,"Delete this student?")) return;
            SwingWorker<Void,Void> w = new SwingWorker<>() {
                @Override protected Void doInBackground() throws Exception {
                    AdminController.deleteStudent(id); return null;
                }
                @Override protected void done() {
                    try { get(); loadStudents(model); }
                    catch (Exception ex) { UITheme.showError(p, ex.getMessage()); }
                }
            };
            w.execute();
        });

        JPanel main = new JPanel(new BorderLayout(0,12));
        main.setOpaque(false);
        main.add(btns, BorderLayout.NORTH);
        main.add(scroll, BorderLayout.CENTER);
        p.add(main, BorderLayout.CENTER);
        return p;
    }

    private void loadStudents(DefaultTableModel model) {
        SwingWorker<List<Student>,Void> w = new SwingWorker<>() {
            @Override protected List<Student> doInBackground() throws Exception {
                return AdminController.getAllStudents();
            }
            @Override protected void done() {
                try {
                    model.setRowCount(0);
                    for (Student s : get())
                        model.addRow(new Object[]{s.getId(),s.getNim(),s.getFullName(),
                            s.getEmail(),s.getPhone(),s.getProgram()});
                } catch (Exception ignored) {}
            }
        };
        w.execute();
    }

    private void showAddStudentDialog(DefaultTableModel model) {
        JTextField fNim     = UITheme.styledField(""); fNim.setPreferredSize(new Dimension(200,36));
        JTextField fName    = UITheme.styledField(""); fName.setPreferredSize(new Dimension(200,36));
        JTextField fEmail   = UITheme.styledField(""); fEmail.setPreferredSize(new Dimension(200,36));
        JTextField fPhone   = UITheme.styledField(""); fPhone.setPreferredSize(new Dimension(200,36));
        JTextField fProgram = UITheme.styledField(""); fProgram.setPreferredSize(new Dimension(200,36));
        JPasswordField fPw  = UITheme.styledPasswordField(); fPw.setPreferredSize(new Dimension(200,36));

        JPanel form = new JPanel(new GridLayout(6,2,8,8));
        form.add(new JLabel("NIM:")); form.add(fNim);
        form.add(new JLabel("Full Name:")); form.add(fName);
        form.add(new JLabel("Email:")); form.add(fEmail);
        form.add(new JLabel("Phone:")); form.add(fPhone);
        form.add(new JLabel("Program:")); form.add(fProgram);
        form.add(new JLabel("Password:")); form.add(fPw);

        int r = JOptionPane.showConfirmDialog(this, form, "Add Student",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (r != JOptionPane.OK_OPTION) return;

        Student s = new Student();
        s.setNim(fNim.getText().trim());
        s.setFullName(fName.getText().trim());
        s.setEmail(fEmail.getText().trim());
        s.setPhone(fPhone.getText().trim());
        s.setProgram(fProgram.getText().trim());
        String pw = new String(fPw.getPassword());

        SwingWorker<Void,Void> w = new SwingWorker<>() {
            @Override protected Void doInBackground() throws Exception {
                AdminController.addStudent(s, pw.isEmpty() ? "password123" : pw); return null;
            }
            @Override protected void done() {
                try { get(); UITheme.showSuccess(AdminDashboard.this,"Student added!"); loadStudents(model); }
                catch (Exception ex) { UITheme.showError(AdminDashboard.this, ex.getMessage()); }
            }
        };
        w.execute();
    }

    private void showEditStudentDialog(Student s, DefaultTableModel model) {
        JTextField fNim     = UITheme.styledField(""); fNim.setText(s.getNim());
        JTextField fName    = UITheme.styledField(""); fName.setText(s.getFullName());
        JTextField fEmail   = UITheme.styledField(""); fEmail.setText(s.getEmail());
        JTextField fPhone   = UITheme.styledField(""); fPhone.setText(s.getPhone());
        JTextField fProgram = UITheme.styledField(""); fProgram.setText(s.getProgram());
        for (JTextField f : new JTextField[]{fNim,fName,fEmail,fPhone,fProgram})
            f.setPreferredSize(new Dimension(200,36));

        JPanel form = new JPanel(new GridLayout(5,2,8,8));
        form.add(new JLabel("NIM:")); form.add(fNim);
        form.add(new JLabel("Full Name:")); form.add(fName);
        form.add(new JLabel("Email:")); form.add(fEmail);
        form.add(new JLabel("Phone:")); form.add(fPhone);
        form.add(new JLabel("Program:")); form.add(fProgram);

        int r = JOptionPane.showConfirmDialog(this, form, "Edit Student",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (r != JOptionPane.OK_OPTION) return;

        s.setNim(fNim.getText().trim());
        s.setFullName(fName.getText().trim());
        s.setEmail(fEmail.getText().trim());
        s.setPhone(fPhone.getText().trim());
        s.setProgram(fProgram.getText().trim());

        SwingWorker<Void,Void> w = new SwingWorker<>() {
            @Override protected Void doInBackground() throws Exception {
                AdminController.updateStudent(s); return null;
            }
            @Override protected void done() {
                try { get(); loadStudents(model); }
                catch (Exception ex) { UITheme.showError(AdminDashboard.this, ex.getMessage()); }
            }
        };
        w.execute();
    }

    // ── Lecturers ─────────────────────────────────────────────────────────────
    private JPanel buildLecturers() {
        JPanel p = new JPanel(new BorderLayout(0,12));
        p.setBackground(UITheme.BEIGE_LIGHT);
        p.setBorder(new EmptyBorder(30,30,30,30));

        JLabel title = new JLabel("Manage Lecturers");
        title.setFont(UITheme.FONT_TITLE);
        title.setForeground(UITheme.ARMY_GREEN_DARK);
        p.add(title, BorderLayout.NORTH);

        String[] cols = {"ID","NIDN","Full Name","Email","Phone","Department"};
        DefaultTableModel model = new DefaultTableModel(cols,0){
            @Override public boolean isCellEditable(int r,int c){return false;}
        };
        JTable table = styledTable(model);
        JButton btnRefresh = UITheme.secondaryButton("🔄 Refresh");
        btnRefresh.addActionListener(e -> loadLecturers(model));
        loadLecturers(model);

        JPanel main = new JPanel(new BorderLayout(0,12));
        main.setOpaque(false);
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        top.setOpaque(false);
        top.add(btnRefresh);
        main.add(top, BorderLayout.NORTH);
        main.add(new JScrollPane(table), BorderLayout.CENTER);
        p.add(main, BorderLayout.CENTER);
        return p;
    }

    private void loadLecturers(DefaultTableModel model) {
        SwingWorker<List<Lecturer>,Void> w = new SwingWorker<>() {
            @Override protected List<Lecturer> doInBackground() throws Exception {
                return AdminController.getAllLecturers();
            }
            @Override protected void done() {
                try {
                    model.setRowCount(0);
                    for (Lecturer l : get())
                        model.addRow(new Object[]{l.getId(),l.getNidn(),l.getFullName(),
                            l.getEmail(),l.getPhone(),l.getDepartment()});
                } catch (Exception ignored) {}
            }
        };
        w.execute();
    }

    // ── Courses ───────────────────────────────────────────────────────────────
    private JPanel buildCourses() {
        JPanel p = new JPanel(new BorderLayout(0,12));
        p.setBackground(UITheme.BEIGE_LIGHT);
        p.setBorder(new EmptyBorder(30,30,30,30));
        JLabel title = new JLabel("Manage Courses");
        title.setFont(UITheme.FONT_TITLE);
        title.setForeground(UITheme.ARMY_GREEN_DARK);
        p.add(title, BorderLayout.NORTH);

        String[] cols = {"ID","Code","Course Name","Credits","Lecturer"};
        DefaultTableModel model = new DefaultTableModel(cols,0){
            @Override public boolean isCellEditable(int r,int c){return false;}
        };
        JTable table = styledTable(model);

        JPanel btns = new JPanel(new FlowLayout(FlowLayout.LEFT,8,0));
        btns.setOpaque(false);
        JButton btnAdd    = UITheme.primaryButton("➕ Add");
        JButton btnDelete = UITheme.dangerButton("🗑️ Delete");
        JButton btnRefresh= UITheme.secondaryButton("🔄 Refresh");
        btns.add(btnAdd); btns.add(btnDelete); btns.add(btnRefresh);

        loadCourses(model);
        btnRefresh.addActionListener(e -> loadCourses(model));

        btnAdd.addActionListener(e -> {
            JTextField fCode   = UITheme.styledField(""); fCode.setPreferredSize(new Dimension(180,36));
            JTextField fName   = UITheme.styledField(""); fName.setPreferredSize(new Dimension(180,36));
            JTextField fCredit = UITheme.styledField("3");fCredit.setPreferredSize(new Dimension(60,36));
            JTextField fLecId  = UITheme.styledField("1");fLecId.setPreferredSize(new Dimension(60,36));
            JPanel form = new JPanel(new GridLayout(4,2,8,8));
            form.add(new JLabel("Code:"));       form.add(fCode);
            form.add(new JLabel("Name:"));       form.add(fName);
            form.add(new JLabel("Credits:"));    form.add(fCredit);
            form.add(new JLabel("Lecturer ID:")); form.add(fLecId);
            int r = JOptionPane.showConfirmDialog(this, form,"Add Course",
                    JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
            if (r != JOptionPane.OK_OPTION) return;
            Course c = new Course();
            c.setCourseCode(fCode.getText().trim());
            c.setCourseName(fName.getText().trim());
            try { c.setCredits(Integer.parseInt(fCredit.getText().trim())); } catch(Exception ex){ c.setCredits(3); }
            try { c.setLecturerId(Integer.parseInt(fLecId.getText().trim())); } catch(Exception ex){ c.setLecturerId(1); }
            SwingWorker<Void,Void> w = new SwingWorker<>() {
                @Override protected Void doInBackground() throws Exception {
                    AdminController.addCourse(c); return null;
                }
                @Override protected void done() {
                    try { get(); loadCourses(model); }
                    catch (Exception ex) { UITheme.showError(AdminDashboard.this, ex.getMessage()); }
                }
            };
            w.execute();
        });

        btnDelete.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) return;
            int id = (int)model.getValueAt(row,0);
            if (!UITheme.confirm(p,"Delete this course?")) return;
            SwingWorker<Void,Void> w = new SwingWorker<>() {
                @Override protected Void doInBackground() throws Exception {
                    AdminController.deleteCourse(id); return null;
                }
                @Override protected void done() {
                    try { get(); loadCourses(model); }
                    catch (Exception ex) { UITheme.showError(p, ex.getMessage()); }
                }
            };
            w.execute();
        });

        JPanel main = new JPanel(new BorderLayout(0,12));
        main.setOpaque(false);
        main.add(btns, BorderLayout.NORTH);
        main.add(new JScrollPane(table), BorderLayout.CENTER);
        p.add(main, BorderLayout.CENTER);
        return p;
    }

    private void loadCourses(DefaultTableModel model) {
        SwingWorker<List<Course>,Void> w = new SwingWorker<>() {
            @Override protected List<Course> doInBackground() throws Exception {
                return AdminController.getAllCourses();
            }
            @Override protected void done() {
                try {
                    model.setRowCount(0);
                    for (Course c : get())
                        model.addRow(new Object[]{c.getId(),c.getCourseCode(),
                            c.getCourseName(),c.getCredits(),c.getLecturerName()});
                } catch (Exception ignored) {}
            }
        };
        w.execute();
    }

    // ── Schedules ─────────────────────────────────────────────────────────────
    private JPanel buildSchedules() {
        JPanel p = new JPanel(new BorderLayout(0,12));
        p.setBackground(UITheme.BEIGE_LIGHT);
        p.setBorder(new EmptyBorder(30,30,30,30));
        JLabel title = new JLabel("Class Schedules");
        title.setFont(UITheme.FONT_TITLE);
        title.setForeground(UITheme.ARMY_GREEN_DARK);
        p.add(title, BorderLayout.NORTH);

        String[] cols = {"ID","Course Code","Course","Day","Start","End","Room","Lecturer"};
        DefaultTableModel model = new DefaultTableModel(cols,0){
            @Override public boolean isCellEditable(int r,int c){return false;}
        };
        JTable table = styledTable(model);
        JButton btnRefresh = UITheme.secondaryButton("🔄 Refresh");
        btnRefresh.addActionListener(e -> loadSchedules(model));
        loadSchedules(model);

        JPanel main = new JPanel(new BorderLayout(0,12));
        main.setOpaque(false);
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        top.setOpaque(false); top.add(btnRefresh);
        main.add(top, BorderLayout.NORTH);
        main.add(new JScrollPane(table), BorderLayout.CENTER);
        p.add(main, BorderLayout.CENTER);
        return p;
    }

    private void loadSchedules(DefaultTableModel model) {
        SwingWorker<List<Schedule>,Void> w = new SwingWorker<>() {
            @Override protected List<Schedule> doInBackground() throws Exception {
                return AdminController.getAllSchedules();
            }
            @Override protected void done() {
                try {
                    model.setRowCount(0);
                    for (Schedule s : get())
                        model.addRow(new Object[]{s.getId(),s.getCourseCode(),s.getCourseName(),
                            s.getDayOfWeek(),s.getStartTime(),s.getEndTime(),
                            s.getRoom(),s.getLecturerName()});
                } catch (Exception ignored) {}
            }
        };
        w.execute();
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    private JTable styledTable(DefaultTableModel model) {
        JTable table = new JTable(model);
        table.setRowHeight(34);
        table.setShowGrid(false);
        table.setIntercellSpacing(new Dimension(0,1));
        table.getTableHeader().setBackground(UITheme.ARMY_GREEN);
        table.getTableHeader().setForeground(Color.WHITE);
        table.getTableHeader().setFont(UITheme.FONT_SUB);
        table.setSelectionBackground(UITheme.ARMY_GREEN_LIGHT);
        table.setSelectionForeground(Color.WHITE);
        table.setFont(UITheme.FONT_BODY);
        return table;
    }

    private void doLogout() {
        if (UITheme.confirm(this,"Log out?")) {
            AuthController.logout(); dispose(); new LoginFrame();
        }
    }
}
