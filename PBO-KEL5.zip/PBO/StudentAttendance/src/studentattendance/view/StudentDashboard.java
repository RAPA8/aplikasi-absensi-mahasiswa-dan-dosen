package studentattendance.view;

import studentattendance.controller.*;
import studentattendance.model.*;
import studentattendance.util.UITheme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;
import java.util.Map;

/**
 * Student Dashboard — sidebar navigation with card widgets.
 */
public class StudentDashboard extends JFrame {

    private Student student;
    private JPanel  contentPanel;
    private CardLayout cardLayout;

    public StudentDashboard() {
        this.student = AuthController.getCurrentStudent();
        UITheme.applyTheme();
        setTitle("AbsenDulu — Student Dashboard");
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) { doLogout(); }
        });
        setSize(1100, 680);
        setLocationRelativeTo(null);
        setMinimumSize(new Dimension(900, 600));

        setLayout(new BorderLayout());
        add(buildSidebar(),  BorderLayout.WEST);
        add(buildContent(),  BorderLayout.CENTER);
        showPanel("HOME");
        setVisible(true);
    }

    // ── Sidebar ───────────────────────────────────────────────────────────────
    private JPanel buildSidebar() {
        JPanel sidebar = UITheme.sidebarPanel();
        sidebar.setPreferredSize(new Dimension(220, 680));
        sidebar.setLayout(null);

        // Avatar & name
        JLabel avatar = new JLabel("👤", SwingConstants.CENTER);
        avatar.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 42));
        avatar.setBounds(0, 20, 220, 50);
        sidebar.add(avatar);

        JLabel name = new JLabel(student.getFullName(), SwingConstants.CENTER);
        name.setFont(UITheme.FONT_SUB);
        name.setForeground(UITheme.BEIGE_LIGHT);
        name.setBounds(0, 72, 220, 22);
        sidebar.add(name);

        JLabel nim = new JLabel("NIM: " + student.getNim(), SwingConstants.CENTER);
        nim.setFont(UITheme.FONT_SMALL);
        nim.setForeground(new Color(0xCCCCBB));
        nim.setBounds(0, 94, 220, 18);
        sidebar.add(nim);

        JSeparator sep = new JSeparator();
        sep.setBounds(20, 122, 180, 1);
        sep.setForeground(new Color(0x7A8344));
        sidebar.add(sep);

        // Nav buttons
        String[][] menus = {
            {"🏠", "Home",       "HOME"},
            {"📅", "Schedule",   "SCHEDULE"},
            {"✅", "Attendance", "ATTEND"},
            {"📊", "History",    "HISTORY"},
            {"📝", "Leave",      "LEAVE"},
        };
        int y = 136;
        for (String[] m : menus) {
            sidebar.add(navButton(m[0] + "  " + m[1], m[2], y));
            y += 52;
        }

        // Logout
        JButton btnLogout = new JButton("⏏  Logout");
        btnLogout.setFont(UITheme.FONT_BUTTON);
        btnLogout.setForeground(new Color(0xFFAAAA));
        btnLogout.setContentAreaFilled(false);
        btnLogout.setBorderPainted(false);
        btnLogout.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnLogout.setBounds(10, 600, 200, 40);
        btnLogout.addActionListener(e -> doLogout());
        sidebar.add(btnLogout);

        return sidebar;
    }

    private JButton navButton(String label, String panel, int y) {
        JButton btn = new JButton(label) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (getModel().isRollover() || getModel().isPressed()) {
                    g2.setColor(new Color(255,255,255,30));
                    g2.fillRoundRect(0,0,getWidth(),getHeight(),10,10);
                }
                g2.setColor(UITheme.BEIGE_LIGHT);
                g2.setFont(getFont());
                g2.drawString(getText(), 20, getHeight()/2 + 5);
                g2.dispose();
            }
        };
        btn.setFont(UITheme.FONT_BODY);
        btn.setBounds(10, y, 200, 42);
        btn.setBorderPainted(false);
        btn.setContentAreaFilled(false);
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.addActionListener(e -> showPanel(panel));
        return btn;
    }

    // ── Content area ──────────────────────────────────────────────────────────
    private JPanel buildContent() {
        cardLayout  = new CardLayout();
        contentPanel = new JPanel(cardLayout);
        contentPanel.setBackground(UITheme.BEIGE_LIGHT);
        contentPanel.add(buildHome(),      "HOME");
        contentPanel.add(buildSchedule(),  "SCHEDULE");
        contentPanel.add(buildAttendance(),"ATTEND");
        contentPanel.add(buildHistory(),   "HISTORY");
        contentPanel.add(buildLeave(),     "LEAVE");
        return contentPanel;
    }

    private void showPanel(String name) { cardLayout.show(contentPanel, name); }

    // ── Home Panel ────────────────────────────────────────────────────────────
    private JPanel buildHome() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(UITheme.BEIGE_LIGHT);
        p.setBorder(new EmptyBorder(30, 30, 30, 30));

        JLabel title = new JLabel("Dashboard Overview");
        title.setFont(UITheme.FONT_TITLE);
        title.setForeground(UITheme.ARMY_GREEN_DARK);
        p.add(title, BorderLayout.NORTH);

        JPanel cards = new JPanel(new GridLayout(2, 3, 16, 16));
        cards.setOpaque(false);
        cards.setBorder(new EmptyBorder(20, 0, 0, 0));

        // Stat cards loaded asynchronously
        JLabel[] vals = new JLabel[6];
        String[] titles = {"Courses", "Present", "Late", "Absent", "Leave Requests", "Attendance %"};
        String[] icons  = {"📚", "✅", "⏰", "❌", "📝", "📊"};
        Color[]  colors = {UITheme.ARMY_GREEN, UITheme.SUCCESS, UITheme.WARNING,
                           UITheme.DANGER, UITheme.INFO, UITheme.ARMY_GREEN_LIGHT};

        for (int i = 0; i < 6; i++) {
            final int idx = i;
            JPanel card = UITheme.card();
            card.setLayout(new BorderLayout());
            JLabel ic = new JLabel(icons[i], SwingConstants.CENTER);
            ic.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 28));
            vals[i] = new JLabel("...", SwingConstants.CENTER);
            vals[i].setFont(new Font("Segoe UI", Font.BOLD, 28));
            vals[i].setForeground(colors[i]);
            JLabel lbl = new JLabel(titles[i], SwingConstants.CENTER);
            lbl.setFont(UITheme.FONT_SMALL);
            lbl.setForeground(UITheme.TEXT_MUTED);
            card.add(ic, BorderLayout.NORTH);
            card.add(vals[i], BorderLayout.CENTER);
            card.add(lbl, BorderLayout.SOUTH);
            cards.add(card);
        }
        p.add(cards, BorderLayout.CENTER);

        // Load stats
        SwingWorker<Map<String, double[]>, Void> w = new SwingWorker<>() {
            @Override protected Map<String, double[]> doInBackground() throws Exception {
                return AttendanceController.getStudentAttendanceStats(student.getId());
            }
            @Override protected void done() {
                try {
                    Map<String, double[]> stats = get();
                    int courses = stats.size();
                    int present = 0, late = 0, absent = 0;
                    double totalPct = 0;
                    for (double[] v : stats.values()) {
                        present += (int) v[0];
                        totalPct += v[2];
                    }
                    vals[0].setText(String.valueOf(courses));
                    vals[1].setText(String.valueOf(present));
                    vals[2].setText(String.valueOf(late));
                    vals[3].setText(String.valueOf(absent));
                    vals[4].setText("—");
                    vals[5].setText(courses > 0 ? String.format("%.1f%%", totalPct / courses) : "0%");
                } catch (Exception ignored) {
                    for (JLabel v : vals) v.setText("—");
                }
            }
        };
        w.execute();

        return p;
    }

    // ── Schedule Panel ────────────────────────────────────────────────────────
    private JPanel buildSchedule() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(UITheme.BEIGE_LIGHT);
        p.setBorder(new EmptyBorder(30, 30, 30, 30));

        JLabel title = new JLabel("My Class Schedule");
        title.setFont(UITheme.FONT_TITLE);
        title.setForeground(UITheme.ARMY_GREEN_DARK);
        p.add(title, BorderLayout.NORTH);

        String[] cols = {"Day", "Course", "Code", "Time", "Room", "Lecturer"};
        DefaultTableModel model = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable table = styledTable(model);
        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.getViewport().setBackground(Color.WHITE);
        p.add(scroll, BorderLayout.CENTER);

        SwingWorker<List<Schedule>, Void> w = new SwingWorker<>() {
            @Override protected List<Schedule> doInBackground() throws Exception {
                return StudentController.getSchedule(student.getId());
            }
            @Override protected void done() {
                try {
                    for (Schedule s : get()) {
                        model.addRow(new Object[]{
                            s.getDayOfWeek(), s.getCourseName(), s.getCourseCode(),
                            s.getStartTime() + " – " + s.getEndTime(),
                            s.getRoom(), s.getLecturerName()
                        });
                    }
                } catch (Exception ex) {
                    UITheme.showError(p, "Error loading schedule: " + ex.getMessage());
                }
            }
        };
        w.execute();
        return p;
    }

    // ── Attendance Check-In Panel ─────────────────────────────────────────────
    private JPanel buildAttendance() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(UITheme.BEIGE_LIGHT);
        p.setBorder(new EmptyBorder(30, 30, 30, 30));

        JLabel title = new JLabel("Mark Attendance");
        title.setFont(UITheme.FONT_TITLE);
        title.setForeground(UITheme.ARMY_GREEN_DARK);

        JPanel form = UITheme.card();
        form.setLayout(new GridBagLayout());
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(8, 8, 8, 8);
        gc.fill = GridBagConstraints.HORIZONTAL;

        gc.gridx=0; gc.gridy=0; gc.gridwidth=2;
        JLabel sub = new JLabel("Enter the 6-character attendance code given by your lecturer.");
        sub.setFont(UITheme.FONT_BODY);
        sub.setForeground(UITheme.TEXT_MUTED);
        form.add(sub, gc);

        gc.gridy=1; gc.gridwidth=1;
        form.add(new JLabel("Attendance Code:"), gc);

        gc.gridx=1;
        JTextField codeField = new JTextField(12);
        codeField.setFont(UITheme.FONT_MONO);
        codeField.setHorizontalAlignment(JTextField.CENTER);
        codeField.setForeground(UITheme.ARMY_GREEN_DARK);
        codeField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(UITheme.BEIGE_DARK, 1, true),
            BorderFactory.createEmptyBorder(8, 12, 8, 12)));
        form.add(codeField, gc);

        gc.gridx=0; gc.gridy=2; gc.gridwidth=2;
        JLabel result = new JLabel(" ", SwingConstants.CENTER);
        result.setFont(UITheme.FONT_SUB);
        form.add(result, gc);

        gc.gridy=3;
        JButton btnSubmit = UITheme.primaryButton("✅  Submit Attendance");
        btnSubmit.setPreferredSize(new Dimension(280, 46));
        form.add(btnSubmit, gc);

        btnSubmit.addActionListener(e -> {
            String code = codeField.getText().trim().toUpperCase();
            if (code.length() != 6) {
                result.setForeground(UITheme.DANGER);
                result.setText("⚠ Code must be 6 characters.");
                return;
            }
            btnSubmit.setEnabled(false);
            SwingWorker<String, Void> w = new SwingWorker<>() {
                @Override protected String doInBackground() throws Exception {
                    return AttendanceController.submitAttendance(student.getId(), code);
                }
                @Override protected void done() {
                    try {
                        String res = get();
                        switch (res) {
                            case "SUCCESS":
                                result.setForeground(UITheme.SUCCESS);
                                result.setText("✅ Attendance marked as PRESENT!");
                                codeField.setText("");
                                break;
                            case "INVALID_CODE":
                                result.setForeground(UITheme.DANGER);
                                result.setText("❌ Invalid or expired code.");
                                break;
                            case "NOT_ENROLLED":
                                result.setForeground(UITheme.DANGER);
                                result.setText("❌ You are not enrolled in this course.");
                                break;
                            case "ALREADY_MARKED":
                                result.setForeground(UITheme.WARNING);
                                result.setText("⚠ You are already marked for this session.");
                                break;
                            default:
                                result.setForeground(UITheme.DANGER);
                                result.setText("❌ Unexpected error.");
                        }
                    } catch (Exception ex) {
                        result.setForeground(UITheme.DANGER);
                        result.setText("❌ " + ex.getMessage());
                    }
                    btnSubmit.setEnabled(true);
                }
            };
            w.execute();
        });

        JPanel center = new JPanel(new GridBagLayout());
        center.setOpaque(false);
        center.add(form);

        p.add(title, BorderLayout.NORTH);
        p.add(center, BorderLayout.CENTER);
        return p;
    }

    // ── History Panel ─────────────────────────────────────────────────────────
    private JPanel buildHistory() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(UITheme.BEIGE_LIGHT);
        p.setBorder(new EmptyBorder(30, 30, 30, 30));

        JLabel title = new JLabel("Attendance History");
        title.setFont(UITheme.FONT_TITLE);
        title.setForeground(UITheme.ARMY_GREEN_DARK);
        p.add(title, BorderLayout.NORTH);

        String[] cols = {"Course", "Date/Time", "Status", "Note"};
        DefaultTableModel model = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable table = styledTable(model);
        // Color rows by status
        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable t, Object v,
                    boolean sel, boolean foc, int row, int col) {
                super.getTableCellRendererComponent(t, v, sel, foc, row, col);
                if (!sel) {
                    String status = (String) model.getValueAt(row, 2);
                    if ("PRESENT".equals(status))  setBackground(new Color(0xE8F5E9));
                    else if ("LATE".equals(status)) setBackground(new Color(0xFFF8E1));
                    else if ("EXCUSED".equals(status)) setBackground(new Color(0xE3F2FD));
                    else setBackground(new Color(0xFFEBEE));
                }
                return this;
            }
        });

        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        p.add(scroll, BorderLayout.CENTER);

        SwingWorker<List<AttendanceRecord>, Void> w = new SwingWorker<>() {
            @Override protected List<AttendanceRecord> doInBackground() throws Exception {
                return AttendanceController.getStudentHistory(student.getId());
            }
            @Override protected void done() {
                try {
                    for (AttendanceRecord r : get()) {
                        model.addRow(new Object[]{
                            r.getCourseName(),
                            r.getCheckIn() != null ? r.getCheckIn().toString().replace("T"," ") : "—",
                            r.getStatus(), r.getNote()
                        });
                    }
                } catch (Exception ex) {
                    UITheme.showError(p, "Error: " + ex.getMessage());
                }
            }
        };
        w.execute();
        return p;
    }

    // ── Leave Panel ───────────────────────────────────────────────────────────
    private JPanel buildLeave() {
        JPanel p = new JPanel(new BorderLayout(0, 16));
        p.setBackground(UITheme.BEIGE_LIGHT);
        p.setBorder(new EmptyBorder(30, 30, 30, 30));

        JLabel title = new JLabel("Leave Requests");
        title.setFont(UITheme.FONT_TITLE);
        title.setForeground(UITheme.ARMY_GREEN_DARK);
        p.add(title, BorderLayout.NORTH);

        // Form card
        JPanel form = UITheme.card();
        form.setLayout(new GridBagLayout());
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(6, 6, 6, 6);
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.anchor = GridBagConstraints.WEST;

        JComboBox<Course> cmbCourse = new JComboBox<>();
        JComboBox<String> cmbType   = new JComboBox<>(new String[]{"SICK","PERMISSION","OTHER"});
        JTextArea txtReason          = new JTextArea(3, 30);
        txtReason.setLineWrap(true);
        txtReason.setWrapStyleWord(true);
        txtReason.setBorder(BorderFactory.createLineBorder(UITheme.BEIGE_DARK));

        gc.gridx=0; gc.gridy=0; form.add(new JLabel("Course:"), gc);
        gc.gridx=1; form.add(cmbCourse, gc);
        gc.gridx=0; gc.gridy=1; form.add(new JLabel("Type:"), gc);
        gc.gridx=1; form.add(cmbType, gc);
        gc.gridx=0; gc.gridy=2; form.add(new JLabel("Reason:"), gc);
        gc.gridx=1; form.add(new JScrollPane(txtReason), gc);

        JButton btnSubmit = UITheme.primaryButton("Submit Request");
        gc.gridx=0; gc.gridy=3; gc.gridwidth=2; gc.anchor=GridBagConstraints.CENTER;
        form.add(btnSubmit, gc);

        // Load courses into combo
        SwingWorker<List<Course>, Void> cw = new SwingWorker<>() {
            @Override protected List<Course> doInBackground() throws Exception {
                return StudentController.getEnrolledCourses(student.getId());
            }
            @Override protected void done() {
                try { for (Course c : get()) cmbCourse.addItem(c); }
                catch (Exception ignored) {}
            }
        };
        cw.execute();

        // History table
        String[] cols = {"Course", "Date", "Type", "Reason", "Status"};
        DefaultTableModel tModel = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable table = styledTable(tModel);
        JScrollPane scroll = new JScrollPane(table);

        btnSubmit.addActionListener(e -> {
            Course course = (Course) cmbCourse.getSelectedItem();
            String reason = txtReason.getText().trim();
            if (course == null || reason.isEmpty()) {
                UITheme.showError(p, "Please fill all fields."); return;
            }
            LeaveRequest lr = new LeaveRequest();
            lr.setStudentId(student.getId());
            lr.setCourseId(course.getId());
            lr.setRequestDate(java.time.LocalDate.now());
            lr.setReason(reason);
            lr.setType((String) cmbType.getSelectedItem());
            SwingWorker<Void, Void> w = new SwingWorker<>() {
                @Override protected Void doInBackground() throws Exception {
                    StudentController.submitLeaveRequest(lr); return null;
                }
                @Override protected void done() {
                    try {
                        get();
                        UITheme.showSuccess(p, "Leave request submitted!");
                        txtReason.setText("");
                        tModel.setRowCount(0);
                        loadLeaveTable(tModel);
                    } catch (Exception ex) {
                        UITheme.showError(p, ex.getMessage());
                    }
                }
            };
            w.execute();
        });

        loadLeaveTable(tModel);

        JPanel top = new JPanel(new BorderLayout());
        top.setOpaque(false);
        top.add(form, BorderLayout.NORTH);
        top.add(scroll, BorderLayout.CENTER);
        p.add(top, BorderLayout.CENTER);
        return p;
    }

    private void loadLeaveTable(DefaultTableModel model) {
        SwingWorker<List<LeaveRequest>, Void> w = new SwingWorker<>() {
            @Override protected List<LeaveRequest> doInBackground() throws Exception {
                return StudentController.getLeaveRequests(student.getId());
            }
            @Override protected void done() {
                try {
                    model.setRowCount(0);
                    for (LeaveRequest lr : get()) {
                        model.addRow(new Object[]{lr.getCourseName(), lr.getRequestDate(),
                            lr.getType(), lr.getReason(), lr.getStatus()});
                    }
                } catch (Exception ignored) {}
            }
        };
        w.execute();
    }

    // ── Utilities ─────────────────────────────────────────────────────────────
    private JTable styledTable(DefaultTableModel model) {
        JTable table = new JTable(model);
        table.setRowHeight(34);
        table.setShowGrid(false);
        table.setIntercellSpacing(new Dimension(0, 1));
        table.getTableHeader().setBackground(UITheme.ARMY_GREEN);
        table.getTableHeader().setForeground(Color.WHITE);
        table.getTableHeader().setFont(UITheme.FONT_SUB);
        table.setSelectionBackground(UITheme.ARMY_GREEN_LIGHT);
        table.setSelectionForeground(Color.WHITE);
        table.setFont(UITheme.FONT_BODY);
        return table;
    }

    private void doLogout() {
        if (UITheme.confirm(this, "Are you sure you want to log out?")) {
            AuthController.logout();
            dispose();
            new LoginFrame();
        }
    }
}
