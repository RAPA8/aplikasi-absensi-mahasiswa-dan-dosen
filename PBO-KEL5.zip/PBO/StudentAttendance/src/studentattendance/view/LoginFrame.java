package studentattendance.view;

import studentattendance.controller.AuthController;
import studentattendance.model.User;
import studentattendance.util.UITheme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;

/**
 * Login screen — Army Green / Beige theme with smooth animations.
 */
public class LoginFrame extends JFrame {

    private JTextField     txtUsername;
    private JPasswordField txtPassword;
    private JButton        btnLogin;
    private JLabel         lblError;
    private JComboBox<String> cmbRole;

    public LoginFrame() {
        UITheme.applyTheme();
        setTitle("Student Attendance System — Login");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(900, 580);
        setLocationRelativeTo(null);
        setResizable(false);
        setUndecorated(true);
        setShape(new RoundRectangle2D.Double(0, 0, 900, 580, 20, 20));

        JPanel root = new JPanel(new BorderLayout());
        root.add(buildLeft(),  BorderLayout.WEST);
        root.add(buildRight(), BorderLayout.CENTER);
        setContentPane(root);
        setVisible(true);
    }

    // ── Left branded panel ────────────────────────────────────────────────────
    private JPanel buildLeft() {
        JPanel panel = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0, UITheme.ARMY_GREEN_DARK,
                        0, getHeight(), UITheme.ARMY_GREEN_LIGHT);
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        panel.setPreferredSize(new Dimension(380, 580));
        panel.setLayout(new GridBagLayout());

        JPanel inner = new JPanel();
        inner.setOpaque(false);
        inner.setLayout(new BoxLayout(inner, BoxLayout.Y_AXIS));

        // Icon/logo
        JLabel icon = new JLabel("📋", SwingConstants.CENTER);
        icon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 64));
        icon.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel title = new JLabel("AbsenDulu", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 32));
        title.setForeground(UITheme.BEIGE_LIGHT);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel sub = new JLabel("<html><div style='text-align:center'>Student Attendance<br>Management System</div></html>", SwingConstants.CENTER);
        sub.setFont(UITheme.FONT_BODY);
        sub.setForeground(new Color(0xCCCCBB));
        sub.setAlignmentX(Component.CENTER_ALIGNMENT);

        JSeparator sep = new JSeparator();
        sep.setForeground(new Color(0x7A8344));
        sep.setMaximumSize(new Dimension(200, 1));
        sep.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel info = new JLabel("<html><div style='text-align:center; color:#BBBBAA; font-size:11px'>"
                + "✓ QR Code Check-In<br>✓ Real-time Tracking<br>✓ PDF/Excel Export<br>✓ Leave Management</div></html>");
        info.setAlignmentX(Component.CENTER_ALIGNMENT);
        info.setHorizontalAlignment(SwingConstants.CENTER);

        inner.add(Box.createVerticalStrut(30));
        inner.add(icon);
        inner.add(Box.createVerticalStrut(12));
        inner.add(title);
        inner.add(Box.createVerticalStrut(6));
        inner.add(sub);
        inner.add(Box.createVerticalStrut(24));
        inner.add(sep);
        inner.add(Box.createVerticalStrut(20));
        inner.add(info);

        panel.add(inner);

        // Close button on left panel
        JButton btnClose = new JButton("✕");
        btnClose.setForeground(new Color(0xCCCCBB));
        btnClose.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        btnClose.setBorderPainted(false);
        btnClose.setContentAreaFilled(false);
        btnClose.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnClose.addActionListener(e -> System.exit(0));
        panel.add(btnClose);
        panel.setLayout(null);
        inner.setBounds(0, 0, 380, 580);
        panel.add(inner);
        btnClose.setBounds(340, 10, 32, 32);

        return panel;
    }

    // ── Right login form ──────────────────────────────────────────────────────
    private JPanel buildRight() {
        JPanel panel = new JPanel(null);
        panel.setBackground(UITheme.BEIGE_LIGHT);

        JLabel lbWelcome = new JLabel("Welcome Back!");
        lbWelcome.setFont(UITheme.FONT_TITLE);
        lbWelcome.setForeground(UITheme.ARMY_GREEN_DARK);
        lbWelcome.setBounds(60, 60, 300, 36);

        JLabel lbSub = new JLabel("Sign in to continue");
        lbSub.setFont(UITheme.FONT_BODY);
        lbSub.setForeground(UITheme.TEXT_MUTED);
        lbSub.setBounds(60, 96, 300, 22);

        // Role
        JLabel lbRole = new JLabel("Login As");
        lbRole.setFont(UITheme.FONT_LABEL);
        lbRole.setForeground(UITheme.TEXT_DARK);
        lbRole.setBounds(60, 140, 260, 20);

        cmbRole = new JComboBox<>(new String[]{"Student", "Lecturer", "Admin"});
        cmbRole.setFont(UITheme.FONT_BODY);
        cmbRole.setBackground(Color.WHITE);
        cmbRole.setBounds(60, 162, 400, 38);
        cmbRole.setBorder(BorderFactory.createLineBorder(UITheme.BEIGE_DARK, 1, true));

        // Username
        JLabel lbUser = new JLabel("Username / NIM / NIDN");
        lbUser.setFont(UITheme.FONT_LABEL);
        lbUser.setForeground(UITheme.TEXT_DARK);
        lbUser.setBounds(60, 218, 300, 20);

        txtUsername = UITheme.styledField("");
        txtUsername.setBounds(60, 240, 400, 42);

        // Password
        JLabel lbPass = new JLabel("Password");
        lbPass.setFont(UITheme.FONT_LABEL);
        lbPass.setForeground(UITheme.TEXT_DARK);
        lbPass.setBounds(60, 300, 200, 20);

        txtPassword = UITheme.styledPasswordField();
        txtPassword.setBounds(60, 322, 400, 42);

        // Error label
        lblError = new JLabel("");
        lblError.setFont(UITheme.FONT_SMALL);
        lblError.setForeground(UITheme.DANGER);
        lblError.setBounds(60, 372, 400, 20);

        // Login button
        btnLogin = UITheme.primaryButton("Sign In →");
        btnLogin.setBounds(60, 400, 400, 46);
        btnLogin.addActionListener(this::doLogin);

        // Enter key
        txtPassword.addKeyListener(new KeyAdapter() {
            @Override public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) doLogin(null);
            }
        });
        txtUsername.addKeyListener(new KeyAdapter() {
            @Override public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) doLogin(null);
            }
        });

        JLabel hint = new JLabel("Default password: password123");
        hint.setFont(UITheme.FONT_SMALL);
        hint.setForeground(UITheme.TEXT_MUTED);
        hint.setBounds(60, 460, 300, 18);

        panel.add(lbWelcome);
        panel.add(lbSub);
        panel.add(lbRole);
        panel.add(cmbRole);
        panel.add(lbUser);
        panel.add(txtUsername);
        panel.add(lbPass);
        panel.add(txtPassword);
        panel.add(lblError);
        panel.add(btnLogin);
        panel.add(hint);

        return panel;
    }

    private void doLogin(ActionEvent e) {
        String username = txtUsername.getText().trim();
        String password = new String(txtPassword.getPassword());
        lblError.setText("");

        if (username.isEmpty() || password.isEmpty()) {
            lblError.setText("⚠ Please enter username and password.");
            return;
        }

        btnLogin.setEnabled(false);
        btnLogin.setText("Signing in...");

        SwingWorker<Boolean, Void> worker = new SwingWorker<>() {
            @Override protected Boolean doInBackground() {
                return AuthController.login(username, password);
            }
            @Override protected void done() {
                try {
                    if (get()) {
                        User user = AuthController.getCurrentUser();
                        dispose();
                        if (user.isStudent()) {
                            new StudentDashboard();
                        } else if (user.isLecturer()) {
                            new LecturerDashboard();
                        } else {
                            new AdminDashboard();
                        }
                    } else {
                        lblError.setText("⚠ Invalid username or password.");
                        btnLogin.setEnabled(true);
                        btnLogin.setText("Sign In →");
                    }
                } catch (Exception ex) {
                    lblError.setText("⚠ Connection error: " + ex.getMessage());
                    btnLogin.setEnabled(true);
                    btnLogin.setText("Sign In →");
                }
            }
        };
        worker.execute();
    }
}
