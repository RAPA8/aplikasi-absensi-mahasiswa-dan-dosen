package studentattendance.view;

import studentattendance.controller.*;
import studentattendance.model.*;
import studentattendance.util.UITheme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

/**
 * Lecturer Dashboard — manage sessions, view recaps, approve leave.
 */
public class LecturerDashboard extends JFrame {

    private Lecturer lecturer;
    private JPanel   contentPanel;
    private CardLayout cardLayout;

    public LecturerDashboard() {
        this.lecturer = AuthController.getCurrentLecturer();
        UITheme.applyTheme();
        setTitle("AbsenDulu — Lecturer Dashboard");
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) { doLogout(); }
        });
        setSize(1200, 700);
        setLocationRelativeTo(null);
        setMinimumSize(new Dimension(960, 640));

        setLayout(new BorderLayout());
        add(buildSidebar(), BorderLayout.WEST);
        add(buildContent(), BorderLayout.CENTER);
        showPanel("HOME");
        setVisible(true);
    }

    // ── Sidebar ───────────────────────────────────────────────────────────────
    private JPanel buildSidebar() {
        JPanel sidebar = UITheme.sidebarPanel();
        sidebar.setPreferredSize(new Dimension(230, 700));
        sidebar.setLayout(null);

        JLabel avatar = new JLabel("👨‍🏫", SwingConstants.CENTER);
        avatar.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 42));
        avatar.setBounds(0, 20, 230, 50);
        sidebar.add(avatar);

        JLabel name = new JLabel(lecturer.getFullName(), SwingConstants.CENTER);
        name.setFont(UITheme.FONT_SUB);
        name.setForeground(UITheme.BEIGE_LIGHT);
        name.setBounds(0, 72, 230, 22);
        sidebar.add(name);

        JLabel nidn = new JLabel("NIDN: " + lecturer.getNidn(), SwingConstants.CENTER);
        nidn.setFont(UITheme.FONT_SMALL);
        nidn.setForeground(new Color(0xCCCCBB));
        nidn.setBounds(0, 94, 230, 18);
        sidebar.add(nidn);

        JSeparator sep = new JSeparator();
        sep.setBounds(20, 122, 190, 1);
        sep.setForeground(new Color(0x7A8344));
        sidebar.add(sep);

        String[][] menus = {
            {"🏠", "Home",        "HOME"},
            {"📅", "Schedule",    "SCHEDULE"},
            {"🔓", "Open Session","SESSION"},
            {"📋", "Recap",       "RECAP"},
            {"📝", "Leave Mgmt",  "LEAVE"},
        };
        int y = 136;
        for (String[] m : menus) {
            sidebar.add(navBtn(m[0]+"  "+m[1], m[2], y));
            y += 52;
        }

        JButton btnLogout = new JButton("⏏  Logout");
        btnLogout.setFont(UITheme.FONT_BUTTON);
        btnLogout.setForeground(new Color(0xFFAAAA));
        btnLogout.setContentAreaFilled(false);
        btnLogout.setBorderPainted(false);
        btnLogout.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnLogout.setBounds(10, 640, 210, 40);
        btnLogout.addActionListener(e -> doLogout());
        sidebar.add(btnLogout);
        return sidebar;
    }

    private JButton navBtn(String label, String panel, int y) {
        JButton btn = new JButton(label) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (getModel().isRollover() || getModel().isPressed()) {
                    g2.setColor(new Color(255,255,255,30));
                    g2.fillRoundRect(0,0,getWidth(),getHeight(),10,10);
                }
                g2.setColor(UITheme.BEIGE_LIGHT);
                g2.setFont(getFont());
                g2.drawString(getText(), 20, getHeight()/2+5);
                g2.dispose();
            }
        };
        btn.setFont(UITheme.FONT_BODY);
        btn.setBounds(10, y, 210, 42);
        btn.setBorderPainted(false);
        btn.setContentAreaFilled(false);
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.addActionListener(e -> showPanel(panel));
        return btn;
    }

    // ── Content ───────────────────────────────────────────────────────────────
    private JPanel buildContent() {
        cardLayout   = new CardLayout();
        contentPanel = new JPanel(cardLayout);
        contentPanel.setBackground(UITheme.BEIGE_LIGHT);
        contentPanel.add(buildHome(),     "HOME");
        contentPanel.add(buildSchedule(), "SCHEDULE");
        contentPanel.add(buildSession(),  "SESSION");
        contentPanel.add(buildRecap(),    "RECAP");
        contentPanel.add(buildLeave(),    "LEAVE");
        return contentPanel;
    }

    private void showPanel(String name) { cardLayout.show(contentPanel, name); }

    // ── Home ──────────────────────────────────────────────────────────────────
    private JPanel buildHome() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(UITheme.BEIGE_LIGHT);
        p.setBorder(new EmptyBorder(30,30,30,30));

        JLabel title = new JLabel("Lecturer Dashboard");
        title.setFont(UITheme.FONT_TITLE);
        title.setForeground(UITheme.ARMY_GREEN_DARK);
        p.add(title, BorderLayout.NORTH);

        JPanel cards = new JPanel(new GridLayout(1, 3, 16, 16));
        cards.setOpaque(false);
        cards.setBorder(new EmptyBorder(20,0,0,0));

        String[] icons  = {"📚","🔓","📋"};
        String[] labels = {"My Courses","Active Sessions","Total Sessions"};
        JLabel[] vals   = new JLabel[3];
        Color[]  colors = {UITheme.ARMY_GREEN, UITheme.SUCCESS, UITheme.INFO};

        for (int i = 0; i < 3; i++) {
            JPanel card = UITheme.card();
            card.setLayout(new BorderLayout());
            JLabel ic = new JLabel(icons[i], SwingConstants.CENTER);
            ic.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 36));
            vals[i] = new JLabel("...", SwingConstants.CENTER);
            vals[i].setFont(new Font("Segoe UI", Font.BOLD, 36));
            vals[i].setForeground(colors[i]);
            JLabel lbl = new JLabel(labels[i], SwingConstants.CENTER);
            lbl.setFont(UITheme.FONT_BODY);
            lbl.setForeground(UITheme.TEXT_MUTED);
            card.add(ic, BorderLayout.NORTH);
            card.add(vals[i], BorderLayout.CENTER);
            card.add(lbl, BorderLayout.SOUTH);
            cards.add(card);
        }
        p.add(cards, BorderLayout.CENTER);

        SwingWorker<int[], Void> w = new SwingWorker<>() {
            @Override protected int[] doInBackground() throws Exception {
                int courses  = LecturerController.getLecturerCourses(lecturer.getId()).size();
                int active   = AttendanceController.getOpenSessions(lecturer.getId()).size();
                int sessions = AttendanceController.getLecturerSessions(lecturer.getId()).size();
                return new int[]{courses, active, sessions};
            }
            @Override protected void done() {
                try {
                    int[] v = get();
                    for (int i = 0; i < 3; i++) vals[i].setText(String.valueOf(v[i]));
                } catch (Exception ignored) {}
            }
        };
        w.execute();
        return p;
    }

    // ── Schedule ──────────────────────────────────────────────────────────────
    private JPanel buildSchedule() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(UITheme.BEIGE_LIGHT);
        p.setBorder(new EmptyBorder(30,30,30,30));
        JLabel title = new JLabel("My Teaching Schedule");
        title.setFont(UITheme.FONT_TITLE);
        title.setForeground(UITheme.ARMY_GREEN_DARK);
        p.add(title, BorderLayout.NORTH);

        String[] cols = {"Day","Course","Time","Room"};
        DefaultTableModel model = new DefaultTableModel(cols,0){
            @Override public boolean isCellEditable(int r,int c){return false;}
        };
        p.add(new JScrollPane(styledTable(model)), BorderLayout.CENTER);

        SwingWorker<List<Schedule>,Void> w = new SwingWorker<>() {
            @Override protected List<Schedule> doInBackground() throws Exception {
                return LecturerController.getLecturerSchedule(lecturer.getId());
            }
            @Override protected void done() {
                try {
                    for (Schedule s : get())
                        model.addRow(new Object[]{s.getDayOfWeek(), s.getCourseName(),
                            s.getStartTime()+" – "+s.getEndTime(), s.getRoom()});
                } catch (Exception ex) { UITheme.showError(p, ex.getMessage()); }
            }
        };
        w.execute();
        return p;
    }

    // ── Open Session ──────────────────────────────────────────────────────────
    private JPanel buildSession() {
        JPanel p = new JPanel(new BorderLayout(0,16));
        p.setBackground(UITheme.BEIGE_LIGHT);
        p.setBorder(new EmptyBorder(30,30,30,30));
        JLabel title = new JLabel("Manage Attendance Sessions");
        title.setFont(UITheme.FONT_TITLE);
        title.setForeground(UITheme.ARMY_GREEN_DARK);
        p.add(title, BorderLayout.NORTH);

        // Form
        JPanel form = UITheme.card();
        form.setLayout(new FlowLayout(FlowLayout.LEFT,12,12));
        JComboBox<Course> cmbCourse = new JComboBox<>();
        JLabel lbCode = new JLabel("Code: —");
        lbCode.setFont(UITheme.FONT_MONO);
        lbCode.setForeground(UITheme.ARMY_GREEN_DARK);
        JButton btnOpen  = UITheme.primaryButton("🔓  Open Session");
        JButton btnClose = UITheme.secondaryButton("🔒  Close Session");

        form.add(new JLabel("Course:"));
        form.add(cmbCourse);
        form.add(btnOpen);
        form.add(lbCode);
        form.add(btnClose);

        // Sessions table
        String[] cols = {"ID","Course","Date","Code","Status","Open Time"};
        DefaultTableModel tModel = new DefaultTableModel(cols,0){
            @Override public boolean isCellEditable(int r,int c){return false;}
        };
        JTable table = styledTable(tModel);
        JScrollPane scroll = new JScrollPane(table);

        // Load courses
        SwingWorker<List<Course>,Void> cw = new SwingWorker<>() {
            @Override protected List<Course> doInBackground() throws Exception {
                return LecturerController.getLecturerCourses(lecturer.getId());
            }
            @Override protected void done() {
                try { for (Course c : get()) cmbCourse.addItem(c); }
                catch (Exception ignored) {}
            }
        };
        cw.execute();
        loadSessions(tModel);

        btnOpen.addActionListener(e -> {
            Course c = (Course)cmbCourse.getSelectedItem();
            if (c == null) { UITheme.showError(p,"Select a course first."); return; }
            SwingWorker<AttendanceSession,Void> w = new SwingWorker<>() {
                @Override protected AttendanceSession doInBackground() throws Exception {
                    return AttendanceController.openSession(c.getId(), lecturer.getId());
                }
                @Override protected void done() {
                    try {
                        AttendanceSession sess = get();
                        lbCode.setText("Code: " + sess.getAttendanceCode());
                        UITheme.showSuccess(p,"Session opened!\nCode: "+sess.getAttendanceCode());
                        loadSessions(tModel);
                    } catch (Exception ex) { UITheme.showError(p, ex.getMessage()); }
                }
            };
            w.execute();
        });

        btnClose.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) { UITheme.showError(p,"Select a session to close."); return; }
            int sessId = (int)tModel.getValueAt(row,0);
            SwingWorker<Void,Void> w = new SwingWorker<>() {
                @Override protected Void doInBackground() throws Exception {
                    AttendanceController.closeSession(sessId); return null;
                }
                @Override protected void done() {
                    try { get(); loadSessions(tModel); }
                    catch (Exception ex) { UITheme.showError(p, ex.getMessage()); }
                }
            };
            w.execute();
        });

        JPanel main = new JPanel(new BorderLayout(0,12));
        main.setOpaque(false);
        main.add(form, BorderLayout.NORTH);
        main.add(scroll, BorderLayout.CENTER);
        p.add(main, BorderLayout.CENTER);
        return p;
    }

    private void loadSessions(DefaultTableModel model) {
        SwingWorker<List<AttendanceSession>,Void> w = new SwingWorker<>() {
            @Override protected List<AttendanceSession> doInBackground() throws Exception {
                return AttendanceController.getLecturerSessions(lecturer.getId());
            }
            @Override protected void done() {
                try {
                    model.setRowCount(0);
                    for (AttendanceSession s : get()) {
                        model.addRow(new Object[]{s.getId(), s.getCourseName(),
                            s.getSessionDate(), s.getAttendanceCode(), s.getStatus(),
                            s.getOpenTime().toString().replace("T"," ")});
                    }
                } catch (Exception ignored) {}
            }
        };
        w.execute();
    }

    // ── Recap ─────────────────────────────────────────────────────────────────
    private JPanel buildRecap() {
        JPanel p = new JPanel(new BorderLayout(0,12));
        p.setBackground(UITheme.BEIGE_LIGHT);
        p.setBorder(new EmptyBorder(30,30,30,30));
        JLabel title = new JLabel("Attendance Recap");
        title.setFont(UITheme.FONT_TITLE);
        title.setForeground(UITheme.ARMY_GREEN_DARK);
        p.add(title, BorderLayout.NORTH);

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        top.setOpaque(false);
        JComboBox<Course> cmbCourse = new JComboBox<>();
        JButton btnLoad = UITheme.primaryButton("Load Recap");
        top.add(new JLabel("Course:"));
        top.add(cmbCourse);
        top.add(btnLoad);

        String[] cols = {"NIM","Name","Present","Late","Excused","Absent","Sessions","Rate"};
        DefaultTableModel model = new DefaultTableModel(cols,0){
            @Override public boolean isCellEditable(int r,int c){return false;}
        };
        JTable table = styledTable(model);
        JScrollPane scroll = new JScrollPane(table);

        SwingWorker<List<Course>,Void> cw = new SwingWorker<>() {
            @Override protected List<Course> doInBackground() throws Exception {
                return LecturerController.getLecturerCourses(lecturer.getId());
            }
            @Override protected void done() {
                try { for (Course c : get()) cmbCourse.addItem(c); }
                catch (Exception ignored) {}
            }
        };
        cw.execute();

        btnLoad.addActionListener(e -> {
            Course c = (Course)cmbCourse.getSelectedItem();
            if (c == null) return;
            SwingWorker<java.util.List<Object[]>,Void> w = new SwingWorker<>() {
                @Override protected java.util.List<Object[]> doInBackground() throws Exception {
                    return AttendanceController.getCourseAttendanceRecap(c.getId());
                }
                @Override protected void done() {
                    try {
                        model.setRowCount(0);
                        for (Object[] row : get()) model.addRow(row);
                    } catch (Exception ex) { UITheme.showError(p, ex.getMessage()); }
                }
            };
            w.execute();
        });

        JPanel main = new JPanel(new BorderLayout(0,12));
        main.setOpaque(false);
        main.add(top, BorderLayout.NORTH);
        main.add(scroll, BorderLayout.CENTER);
        p.add(main, BorderLayout.CENTER);
        return p;
    }

    // ── Leave Management ──────────────────────────────────────────────────────
    private JPanel buildLeave() {
        JPanel p = new JPanel(new BorderLayout(0,12));
        p.setBackground(UITheme.BEIGE_LIGHT);
        p.setBorder(new EmptyBorder(30,30,30,30));
        JLabel title = new JLabel("Leave Request Management");
        title.setFont(UITheme.FONT_TITLE);
        title.setForeground(UITheme.ARMY_GREEN_DARK);
        p.add(title, BorderLayout.NORTH);

        String[] cols = {"ID","Student","Course","Date","Type","Reason","Status"};
        DefaultTableModel model = new DefaultTableModel(cols,0){
            @Override public boolean isCellEditable(int r,int c){return false;}
        };
        JTable table = styledTable(model);
        JScrollPane scroll = new JScrollPane(table);

        JPanel btns = new JPanel(new FlowLayout(FlowLayout.LEFT));
        btns.setOpaque(false);
        JButton btnApprove = UITheme.primaryButton("✅ Approve");
        JButton btnReject  = UITheme.dangerButton("❌ Reject");
        JButton btnRefresh = UITheme.secondaryButton("🔄 Refresh");
        btns.add(btnApprove); btns.add(btnReject); btns.add(btnRefresh);

        loadLeaveRequests(model);

        btnApprove.addActionListener(e -> processLeave(table,model,"APPROVED"));
        btnReject.addActionListener(e  -> processLeave(table,model,"REJECTED"));
        btnRefresh.addActionListener(e -> loadLeaveRequests(model));

        JPanel main = new JPanel(new BorderLayout(0,12));
        main.setOpaque(false);
        main.add(btns, BorderLayout.NORTH);
        main.add(scroll, BorderLayout.CENTER);
        p.add(main, BorderLayout.CENTER);
        return p;
    }

    private void loadLeaveRequests(DefaultTableModel model) {
        SwingWorker<List<LeaveRequest>,Void> w = new SwingWorker<>() {
            @Override protected List<LeaveRequest> doInBackground() throws Exception {
                return LecturerController.getPendingLeaveRequests(lecturer.getId());
            }
            @Override protected void done() {
                try {
                    model.setRowCount(0);
                    for (LeaveRequest lr : get()) {
                        model.addRow(new Object[]{lr.getId(), lr.getStudentName(),
                            lr.getCourseName(), lr.getRequestDate(),
                            lr.getType(), lr.getReason(), lr.getStatus()});
                    }
                } catch (Exception ignored) {}
            }
        };
        w.execute();
    }

    private void processLeave(JTable table, DefaultTableModel model, String status) {
        int row = table.getSelectedRow();
        if (row < 0) { UITheme.showError(this, "Select a request first."); return; }
        int id = (int)model.getValueAt(row,0);
        String note = JOptionPane.showInputDialog(this, "Note (optional):", "");
        SwingWorker<Void,Void> w = new SwingWorker<>() {
            @Override protected Void doInBackground() throws Exception {
                LecturerController.processLeaveRequest(id, status, note); return null;
            }
            @Override protected void done() {
                try { get(); loadLeaveRequests(model); }
                catch (Exception ex) { UITheme.showError(LecturerDashboard.this, ex.getMessage()); }
            }
        };
        w.execute();
    }

    private JTable styledTable(DefaultTableModel model) {
        JTable table = new JTable(model);
        table.setRowHeight(34);
        table.setShowGrid(false);
        table.setIntercellSpacing(new Dimension(0,1));
        table.getTableHeader().setBackground(UITheme.ARMY_GREEN);
        table.getTableHeader().setForeground(Color.WHITE);
        table.getTableHeader().setFont(UITheme.FONT_SUB);
        table.setSelectionBackground(UITheme.ARMY_GREEN_LIGHT);
        table.setSelectionForeground(Color.WHITE);
        table.setFont(UITheme.FONT_BODY);
        return table;
    }

    private void doLogout() {
        if (UITheme.confirm(this,"Log out?")) {
            AuthController.logout(); dispose(); new LoginFrame();
        }
    }
}
