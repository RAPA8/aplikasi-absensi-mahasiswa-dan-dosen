package studentattendance;

import studentattendance.db.DatabaseConnection;
import studentattendance.util.UITheme;
import studentattendance.view.LoginFrame;

import javax.swing.*;

/**
 * Application entry point.
 *
 * Prerequisites:
 *  1. XAMPP running — MySQL on port 3306
 *  2. Run database/attendance_db.sql to create schema + seed data
 *  3. Add lib/mysql-connector-j-8.0.33.jar to project classpath in NetBeans
 */
public class StudentAttendance {

    public static void main(String[] args) {
        // Apply global theme
        UITheme.applyTheme();

        // Test DB connection before opening UI
        SwingUtilities.invokeLater(() -> {
            if (!DatabaseConnection.testConnection()) {
                JOptionPane.showMessageDialog(null,
                    "<html><b>Cannot connect to database!</b><br><br>"
                    + "Please make sure:<br>"
                    + "• XAMPP is running (MySQL on port 3306)<br>"
                    + "• Database 'attendance_db' exists<br>"
                    + "• Run: database/attendance_db.sql in phpMyAdmin<br><br>"
                    + "The application will open anyway — some features may not work.",
                    "Database Connection Warning",
                    JOptionPane.WARNING_MESSAGE);
            }
            new LoginFrame();
        });
    }
}
