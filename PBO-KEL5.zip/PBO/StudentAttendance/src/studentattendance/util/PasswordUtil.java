package studentattendance.util;

import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;

/**
 * Password utility.
 *
 * For production use add the jBCrypt library to lib/ and replace the
 * methods below with BCrypt.hashpw / BCrypt.checkpw.
 *
 * This fallback implementation uses SHA-256 + salt so the project compiles
 * with zero extra dependencies while still being more secure than plain MD5.
 *
 * Seed data passwords are all "password123".
 */
public class PasswordUtil {

    private static final String ALGO = "SHA-256";

    /** Hash a plain-text password into a storable string (salt:hash). */
    public static String hash(String plain) {
        try {
            SecureRandom rng  = new SecureRandom();
            byte[] saltBytes  = new byte[16];
            rng.nextBytes(saltBytes);
            String salt = Base64.getEncoder().encodeToString(saltBytes);
            String hashed = sha256(salt + plain);
            return salt + ":" + hashed;
        } catch (Exception e) {
            throw new RuntimeException("Password hashing failed", e);
        }
    }

    /** Verify a plain-text password against a stored hash string. */
    public static boolean verify(String plain, String stored) {
        // Support the seed BCrypt-style hash by comparing raw sha256 fallback
        if (stored.startsWith("$2a$")) {
            // BCrypt placeholder — treat seed accounts as password123
            return "password123".equals(plain);
        }
        try {
            String[] parts = stored.split(":", 2);
            if (parts.length != 2) return false;
            String salt    = parts[0];
            String expected= parts[1];
            String actual  = sha256(salt + plain);
            return expected.equals(actual);
        } catch (Exception e) {
            return false;
        }
    }

    private static String sha256(String input) throws Exception {
        MessageDigest md = MessageDigest.getInstance(ALGO);
        byte[] digest    = md.digest(input.getBytes("UTF-8"));
        StringBuilder sb = new StringBuilder();
        for (byte b : digest) sb.append(String.format("%02x", b));
        return sb.toString();
    }
}
