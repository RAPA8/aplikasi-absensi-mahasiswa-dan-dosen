package studentattendance.util;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;

/**
 * Centralized design system.
 * Color palette:  Army Green #5D6532  |  Beige #EDE8D0
 */
public class UITheme {

    // ── Palette ───────────────────────────────────────────────────────────────
    public static final Color ARMY_GREEN      = new Color(0x5D6532);
    public static final Color ARMY_GREEN_DARK = new Color(0x454A24);
    public static final Color ARMY_GREEN_LIGHT= new Color(0x7A8344);
    public static final Color BEIGE           = new Color(0xEDE8D0);
    public static final Color BEIGE_DARK      = new Color(0xD8D2B2);
    public static final Color BEIGE_LIGHT     = new Color(0xF8F5E8);
    public static final Color WHITE           = Color.WHITE;
    public static final Color TEXT_DARK       = new Color(0x2C2C1E);
    public static final Color TEXT_MUTED      = new Color(0x7A7A5A);
    public static final Color DANGER          = new Color(0xC0392B);
    public static final Color SUCCESS         = new Color(0x27AE60);
    public static final Color WARNING         = new Color(0xF39C12);
    public static final Color INFO            = new Color(0x2980B9);

    // ── Fonts ─────────────────────────────────────────────────────────────────
    public static final Font FONT_TITLE  = new Font("Segoe UI", Font.BOLD,  24);
    public static final Font FONT_HEADER = new Font("Segoe UI", Font.BOLD,  16);
    public static final Font FONT_SUB    = new Font("Segoe UI", Font.BOLD,  13);
    public static final Font FONT_BODY   = new Font("Segoe UI", Font.PLAIN, 13);
    public static final Font FONT_SMALL  = new Font("Segoe UI", Font.PLAIN, 11);
    public static final Font FONT_LABEL  = new Font("Segoe UI", Font.BOLD,  12);
    public static final Font FONT_BUTTON = new Font("Segoe UI", Font.BOLD,  13);
    public static final Font FONT_MONO   = new Font("Consolas",  Font.BOLD,  28);

    // ── Borders ───────────────────────────────────────────────────────────────
    public static Border roundedBorder(int radius) {
        return new EmptyBorder(radius / 2, radius, radius / 2, radius);
    }

    // ── Global L&F Setup ─────────────────────────────────────────────────────
    public static void applyTheme() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}

        UIManager.put("Panel.background", BEIGE_LIGHT);
        UIManager.put("OptionPane.background", BEIGE_LIGHT);
        UIManager.put("OptionPane.messageForeground", TEXT_DARK);
        UIManager.put("Button.font", FONT_BUTTON);
        UIManager.put("Label.font", FONT_BODY);
        UIManager.put("TextField.font", FONT_BODY);
        UIManager.put("PasswordField.font", FONT_BODY);
        UIManager.put("ComboBox.font", FONT_BODY);
        UIManager.put("Table.font", FONT_BODY);
        UIManager.put("TableHeader.font", FONT_SUB);
        UIManager.put("TableHeader.background", ARMY_GREEN);
        UIManager.put("TableHeader.foreground", WHITE);
        UIManager.put("Table.selectionBackground", ARMY_GREEN_LIGHT);
        UIManager.put("Table.selectionForeground", WHITE);
        UIManager.put("ScrollPane.background", BEIGE_LIGHT);
        UIManager.put("TabbedPane.selected", BEIGE);
        UIManager.put("TabbedPane.background", BEIGE_LIGHT);
        UIManager.put("TabbedPane.font", FONT_SUB);
    }

    // ── Factory: Primary Button ───────────────────────────────────────────────
    public static JButton primaryButton(String text) {
        JButton btn = new JButton(text) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (getModel().isPressed()) {
                    g2.setColor(ARMY_GREEN_DARK);
                } else if (getModel().isRollover()) {
                    g2.setColor(ARMY_GREEN_LIGHT);
                } else {
                    g2.setColor(ARMY_GREEN);
                }
                g2.fill(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 12, 12));
                g2.setColor(WHITE);
                g2.setFont(getFont());
                FontMetrics fm = g2.getFontMetrics();
                int x = (getWidth()  - fm.stringWidth(getText())) / 2;
                int y = (getHeight() + fm.getAscent() - fm.getDescent()) / 2;
                g2.drawString(getText(), x, y);
                g2.dispose();
            }
        };
        btn.setFont(FONT_BUTTON);
        btn.setForeground(WHITE);
        btn.setPreferredSize(new Dimension(160, 42));
        btn.setBorderPainted(false);
        btn.setContentAreaFilled(false);
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return btn;
    }

    // ── Factory: Danger Button ────────────────────────────────────────────────
    public static JButton dangerButton(String text) {
        JButton btn = primaryButton(text);
        btn.setBackground(DANGER);
        return btn;
    }

    // ── Factory: Secondary Button ─────────────────────────────────────────────
    public static JButton secondaryButton(String text) {
        JButton btn = new JButton(text) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isRollover() ? BEIGE_DARK : BEIGE);
                g2.fill(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 12, 12));
                g2.setColor(ARMY_GREEN_DARK);
                g2.setStroke(new BasicStroke(1.5f));
                g2.draw(new RoundRectangle2D.Double(1, 1, getWidth()-2, getHeight()-2, 12, 12));
                g2.setColor(ARMY_GREEN_DARK);
                g2.setFont(getFont());
                FontMetrics fm = g2.getFontMetrics();
                int x = (getWidth()  - fm.stringWidth(getText())) / 2;
                int y = (getHeight() + fm.getAscent() - fm.getDescent()) / 2;
                g2.drawString(getText(), x, y);
                g2.dispose();
            }
        };
        btn.setFont(FONT_BUTTON);
        btn.setBorderPainted(false);
        btn.setContentAreaFilled(false);
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(160, 42));
        return btn;
    }

    // ── Factory: Styled Text Field ────────────────────────────────────────────
    public static JTextField styledField(String placeholder) {
        JTextField field = new JTextField(20);
        field.setFont(FONT_BODY);
        field.setBackground(WHITE);
        field.setForeground(TEXT_DARK);
        field.setCaretColor(ARMY_GREEN);
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BEIGE_DARK, 1, true),
            BorderFactory.createEmptyBorder(8, 12, 8, 12)
        ));
        return field;
    }

    // ── Factory: Styled Password Field ────────────────────────────────────────
    public static JPasswordField styledPasswordField() {
        JPasswordField field = new JPasswordField(20);
        field.setFont(FONT_BODY);
        field.setBackground(WHITE);
        field.setForeground(TEXT_DARK);
        field.setCaretColor(ARMY_GREEN);
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BEIGE_DARK, 1, true),
            BorderFactory.createEmptyBorder(8, 12, 8, 12)
        ));
        return field;
    }

    // ── Factory: Card Panel ───────────────────────────────────────────────────
    public static JPanel card() {
        JPanel panel = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(WHITE);
                g2.fill(new RoundRectangle2D.Double(4, 4, getWidth()-8, getHeight()-8, 16, 16));
                // shadow
                g2.setColor(new Color(0, 0, 0, 20));
                g2.setStroke(new BasicStroke(1));
                g2.draw(new RoundRectangle2D.Double(4, 4, getWidth()-9, getHeight()-9, 16, 16));
                g2.dispose();
                super.paintComponent(g);
            }
        };
        panel.setOpaque(false);
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));
        return panel;
    }

    // ── Factory: Sidebar Panel ────────────────────────────────────────────────
    public static JPanel sidebarPanel() {
        JPanel panel = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0, ARMY_GREEN_DARK, 0, getHeight(), ARMY_GREEN);
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.dispose();
            }
        };
        panel.setOpaque(false);
        return panel;
    }

    // ── Helper: Show error dialog ──────────────────────────────────────────────
    public static void showError(Component parent, String message) {
        JOptionPane.showMessageDialog(parent, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    // ── Helper: Show success dialog ────────────────────────────────────────────
    public static void showSuccess(Component parent, String message) {
        JOptionPane.showMessageDialog(parent, message, "Success", JOptionPane.INFORMATION_MESSAGE);
    }

    // ── Helper: Confirm dialog ─────────────────────────────────────────────────
    public static boolean confirm(Component parent, String message) {
        return JOptionPane.showConfirmDialog(parent, message, "Confirm",
                JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION;
    }
}
