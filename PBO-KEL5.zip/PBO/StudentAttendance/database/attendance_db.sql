-- ============================================================
--  Student Attendance Management System - Database Schema
--  Compatible with XAMPP MySQL
-- ============================================================

CREATE DATABASE IF NOT EXISTS attendance_db
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE attendance_db;

-- -----------------------------------------------------------
-- Table: users  (login credentials for all roles)
-- -----------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    username    VARCHAR(50)  NOT NULL UNIQUE,
    password    VARCHAR(255) NOT NULL,   -- BCrypt hash
    role        ENUM('STUDENT','LECTURER','ADMIN') NOT NULL,
    is_active   TINYINT(1) DEFAULT 1,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- -----------------------------------------------------------
-- Table: students
-- -----------------------------------------------------------
CREATE TABLE IF NOT EXISTS students (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    user_id     INT NOT NULL,
    nim         VARCHAR(20)  NOT NULL UNIQUE,
    full_name   VARCHAR(100) NOT NULL,
    email       VARCHAR(100),
    phone       VARCHAR(20),
    program     VARCHAR(100),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- -----------------------------------------------------------
-- Table: lecturers
-- -----------------------------------------------------------
CREATE TABLE IF NOT EXISTS lecturers (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    user_id     INT NOT NULL,
    nidn        VARCHAR(20)  NOT NULL UNIQUE,
    full_name   VARCHAR(100) NOT NULL,
    email       VARCHAR(100),
    phone       VARCHAR(20),
    department  VARCHAR(100),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- -----------------------------------------------------------
-- Table: courses
-- -----------------------------------------------------------
CREATE TABLE IF NOT EXISTS courses (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    course_code VARCHAR(20)  NOT NULL UNIQUE,
    course_name VARCHAR(150) NOT NULL,
    credits     INT DEFAULT 3,
    lecturer_id INT,
    FOREIGN KEY (lecturer_id) REFERENCES lecturers(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- -----------------------------------------------------------
-- Table: class_schedules
-- -----------------------------------------------------------
CREATE TABLE IF NOT EXISTS class_schedules (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    course_id   INT NOT NULL,
    day_of_week ENUM('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday') NOT NULL,
    start_time  TIME NOT NULL,
    end_time    TIME NOT NULL,
    room        VARCHAR(50),
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- -----------------------------------------------------------
-- Table: student_courses  (enrollment)
-- -----------------------------------------------------------
CREATE TABLE IF NOT EXISTS student_courses (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    student_id  INT NOT NULL,
    course_id   INT NOT NULL,
    semester    VARCHAR(20),
    UNIQUE KEY uq_enrollment (student_id, course_id),
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY (course_id)  REFERENCES courses(id)  ON DELETE CASCADE
) ENGINE=InnoDB;

-- -----------------------------------------------------------
-- Table: attendance_sessions  (opened by lecturer)
-- -----------------------------------------------------------
CREATE TABLE IF NOT EXISTS attendance_sessions (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    course_id       INT NOT NULL,
    lecturer_id     INT NOT NULL,
    session_date    DATE NOT NULL,
    open_time       DATETIME NOT NULL,
    close_time      DATETIME,
    attendance_code VARCHAR(20) NOT NULL UNIQUE,
    qr_data         TEXT,
    status          ENUM('OPEN','CLOSED') DEFAULT 'OPEN',
    FOREIGN KEY (course_id)   REFERENCES courses(id)   ON DELETE CASCADE,
    FOREIGN KEY (lecturer_id) REFERENCES lecturers(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- -----------------------------------------------------------
-- Table: attendance_records
-- -----------------------------------------------------------
CREATE TABLE IF NOT EXISTS attendance_records (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    session_id   INT NOT NULL,
    student_id   INT NOT NULL,
    check_in     DATETIME,
    status       ENUM('PRESENT','ABSENT','LATE','EXCUSED') DEFAULT 'ABSENT',
    note         VARCHAR(255),
    UNIQUE KEY uq_record (session_id, student_id),
    FOREIGN KEY (session_id)  REFERENCES attendance_sessions(id) ON DELETE CASCADE,
    FOREIGN KEY (student_id)  REFERENCES students(id)            ON DELETE CASCADE
) ENGINE=InnoDB;

-- -----------------------------------------------------------
-- Table: leave_requests
-- -----------------------------------------------------------
CREATE TABLE IF NOT EXISTS leave_requests (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    student_id   INT NOT NULL,
    course_id    INT NOT NULL,
    session_id   INT,
    request_date DATE NOT NULL,
    reason       TEXT NOT NULL,
    type         ENUM('SICK','PERMISSION','OTHER') DEFAULT 'PERMISSION',
    status       ENUM('PENDING','APPROVED','REJECTED') DEFAULT 'PENDING',
    lecturer_note VARCHAR(255),
    created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY (course_id)  REFERENCES courses(id)  ON DELETE CASCADE,
    FOREIGN KEY (session_id) REFERENCES attendance_sessions(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ============================================================
--  SEED DATA
-- ============================================================

-- Passwords are BCrypt of "password123"
INSERT INTO users (username, password, role) VALUES
('admin',   '$2a$12$KIXwTVz.v4JkD0z7FBn3cOa2JpEq5z1UyP0sT9bRYnVrNkLmO7CWC', 'ADMIN'),
('S001',    '$2a$12$KIXwTVz.v4JkD0z7FBn3cOa2JpEq5z1UyP0sT9bRYnVrNkLmO7CWC', 'STUDENT'),
('S002',    '$2a$12$KIXwTVz.v4JkD0z7FBn3cOa2JpEq5z1UyP0sT9bRYnVrNkLmO7CWC', 'STUDENT'),
('S003',    '$2a$12$KIXwTVz.v4JkD0z7FBn3cOa2JpEq5z1UyP0sT9bRYnVrNkLmO7CWC', 'STUDENT'),
('L001',    '$2a$12$KIXwTVz.v4JkD0z7FBn3cOa2JpEq5z1UyP0sT9bRYnVrNkLmO7CWC', 'LECTURER'),
('L002',    '$2a$12$KIXwTVz.v4JkD0z7FBn3cOa2JpEq5z1UyP0sT9bRYnVrNkLmO7CWC', 'LECTURER');

INSERT INTO students (user_id, nim, full_name, email, program) VALUES
(2, 'S001', 'Budi Santoso',    'budi@student.ac.id',   'Information Systems'),
(3, 'S002', 'Siti Rahayu',     'siti@student.ac.id',   'Information Systems'),
(4, 'S003', 'Andi Kurniawan',  'andi@student.ac.id',   'Computer Science');

INSERT INTO lecturers (user_id, nidn, full_name, email, department) VALUES
(5, 'L001', 'Dr. Rudi Hartono',   'rudi@lecturer.ac.id',  'Information Systems'),
(6, 'L002', 'Dr. Maya Sari',      'maya@lecturer.ac.id',  'Computer Science');

INSERT INTO courses (course_code, course_name, credits, lecturer_id) VALUES
('IS101', 'Object Oriented Programming',  3, 1),
('IS102', 'Database Systems',             3, 1),
('CS201', 'Data Structures & Algorithms', 3, 2),
('CS202', 'Computer Networks',            3, 2);

INSERT INTO class_schedules (course_id, day_of_week, start_time, end_time, room) VALUES
(1, 'Monday',    '08:00:00', '10:30:00', 'Room A101'),
(2, 'Wednesday', '10:00:00', '12:30:00', 'Room B202'),
(3, 'Tuesday',   '13:00:00', '15:30:00', 'Room C303'),
(4, 'Thursday',  '08:00:00', '10:30:00', 'Lab 1');

INSERT INTO student_courses (student_id, course_id, semester) VALUES
(1, 1, '2025/2026-1'), (1, 2, '2025/2026-1'), (1, 3, '2025/2026-1'),
(2, 1, '2025/2026-1'), (2, 2, '2025/2026-1'), (2, 4, '2025/2026-1'),
(3, 3, '2025/2026-1'), (3, 4, '2025/2026-1');
